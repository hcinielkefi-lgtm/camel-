package com.acme.payment;
import java.io.InputStream;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPathFactory;
import org.apache.camel.CamelExecutionException;
import org.apache.camel.RoutesBuilder;
import org.apache.camel.component.mock.MockEndpoint;
import org.apache.camel.test.junit5.CamelTestSupport;
import org.junit.jupiter.api.Test;
import org.w3c.dom.Document;
import static org.junit.jupiter.api.Assertions.*;

public class PaymentRouteTest extends CamelTestSupport {
  @Override protected RoutesBuilder createRouteBuilder() { return new PaymentRoutes("mock:result"); }
  private String resource(String p) throws Exception { try (InputStream in=getClass().getResourceAsStream(p)) { return new String(in.readAllBytes()); } }
  @Test void normalizesValidPayment() throws Exception {
    MockEndpoint result=getMockEndpoint("mock:result"); result.expectedMessageCount(1); result.expectedHeaderReceived("normalized",true);
    template.sendBody("direct:payment-in",resource("/input/payment.xml")); result.assertIsSatisfied();
    String xml=result.getExchanges().get(0).getMessage().getBody(String.class);
    var f=DocumentBuilderFactory.newInstance(); f.setNamespaceAware(true); Document d=f.newDocumentBuilder().parse(new java.io.ByteArrayInputStream(xml.getBytes())); var xp=XPathFactory.newInstance().newXPath();
    assertEquals("PAY-001",xp.evaluate("/CanonicalPayment/PaymentId",d));
    assertEquals("120.00",xp.evaluate("/CanonicalPayment/Amount",d));
    assertEquals("EUR",xp.evaluate("/CanonicalPayment/Amount/@currency",d));
    assertEquals("WEB",xp.evaluate("/CanonicalPayment/Channel",d));
  }
  @Test void rejectsInvalidPayment() throws Exception {
    assertThrows(CamelExecutionException.class,()->template.requestBody("direct:payment-in",resource("/input/payment-invalid.xml"),String.class));
  }
}

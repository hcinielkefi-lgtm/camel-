<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="3.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:xs="http://www.w3.org/2001/XMLSchema" exclude-result-prefixes="xs">
  <xsl:output method="xml" omit-xml-declaration="yes" indent="no"/>
  <xsl:param name="tenantId" as="xs:string?" select="'UNKNOWN'"/>
  <xsl:template match="/Payment">
    <CanonicalPayment>
      <PaymentId><xsl:value-of select="Id"/></PaymentId>
      <Amount currency="{Amount/@currency}"><xsl:value-of select="format-number(xs:decimal(Amount), '0.00')"/></Amount>
      <Channel><xsl:value-of select="upper-case(Channel)"/></Channel>
      <Tenant><xsl:value-of select="$tenantId"/></Tenant>
    </CanonicalPayment>
  </xsl:template>
</xsl:stylesheet>

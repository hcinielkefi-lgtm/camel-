package com.acme.payment;
import org.apache.camel.builder.RouteBuilder;
public class PaymentRoutes extends RouteBuilder {
  private final String outputUri;
  public PaymentRoutes() { this("log:payment-normalized"); }
  public PaymentRoutes(String outputUri) { this.outputUri = outputUri; }
  @Override public void configure() {
    onException(IllegalArgumentException.class).handled(false).maximumRedeliveries(0);
    from("direct:payment-in")
      .routeId("payment-entry")
      .setHeader("tenantId").constant("TENANT-DEMO")
      .to("kamelet:payment-normalizer")
      .to(outputUri);
  }
}

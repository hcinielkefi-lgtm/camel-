# Apache Camel 4.22 RAG + Non-régression — n8n/Qdrant/Podman

## Ce pack contient
- 3 workflows n8n importables : ingestion, query/impact, exécution de tests.
- `camel-rag-analyzer`: parse Kamelet YAML, Java DSL, YAML/XML DSL, XSLT 3, XSD et POM et produit documents + graphe canonique.
- Qdrant pour les embeddings/connaissance sémantique.
- PostgreSQL pour le knowledge graph exact et les résultats de tests.
- Ollama: `qwen3-embedding:0.6b` + `qwen3:8b-q4_K_M`.
- Apache Tika pour PDF/DOCX/PPTX (à raccorder au workflow documentaire).
- Test Runner Maven/Java 21 self-hosted.
- Projet exemple Camel 4.22 avec Kamelet + validator XSD + XSLT 3 Saxon + tests JUnit 5.

## Installation rapide
```bash
cp .env.example .env
openssl rand -hex 32        # N8N_ENCRYPTION_KEY
openssl rand -base64 36     # POSTGRES_PASSWORD
chmod 600 .env
./scripts/01-install-podman.sh
./scripts/02-attach-qdrant.sh   # si Qdrant est déjà un conteneur Podman
./scripts/03-init-qdrant.sh
./scripts/04-start.sh
```
Si vous préférez que le pack lance Qdrant :
```bash
podman compose -f podman-compose.yml -f podman-compose.qdrant.yml up -d --build
```

## n8n
Ouvrir `http://127.0.0.1:5678`, créer la credential PostgreSQL suivante et l'affecter à tous les nodes PostgreSQL après import :
- host `postgres`
- port `5432`
- database `n8n`
- user `n8n`
- password = `POSTGRES_PASSWORD`

Importer :
1. `workflows/01-ingestion-camel422.json`
2. `workflows/02-query-impact-camel422.json`
3. `workflows/03-regression-runner-camel422.json`

Puis activer les workflows.

## Ingestion exemple
```bash
./scripts/05-ingest-example.sh
```
Question d'impact :
```bash
curl -sS http://127.0.0.1:5678/webhook/camel-rag-query \
 -H 'Content-Type: application/json' \
 -d '{"question":"Quel impact si le mapping payment-normalize.xsl change ? Quels tests et contrats XML sont liés ?","artifact_id":"payment-normalize.xsl"}' | jq
```

## Exécuter les tests Camel
```bash
./scripts/06-test-example.sh
```
Ou directement dans le runner :
```bash
curl -sS http://test-runner:8090/run -H 'Content-Type: application/json' -d '{"project_path":"example-camel"}'
```

## Projet exemple
Flux :
```text
direct:payment-in
  -> Kamelet payment-normalizer
       -> validator:payment-input.xsd
       -> xslt-saxon:payment-normalize.xsl
       -> kamelet:sink
  -> direct:payment-normalized
```
Tests :
- `normalizesValidPayment`: vérifie Id, montant/devise, Channel en majuscules.
- `rejectsInvalidPayment`: vérifie le rejet XSD (currency obligatoire).

## Validation locale incluse
`python3 scripts/validate_static.py` valide JSON n8n, YAML, XML, XSD, XSLT.
Les tests Python de l'analyseur sont dans `analyzer/tests/test_analyzer.py`.
Pour le test Camel réel, le runner exécute `mvn -B -ntp test` dans l'image Maven 3.9.16 + Java 21.

## Notes de production
- Protéger les webhooks (API gateway/OIDC/mTLS).
- Ne jamais indexer PAN/CVV/secrets; ajouter un DLP d'entreprise avant Qdrant.
- Ajouter Camel Catalog 4.22 au `analyzer` pour validation exhaustive des options de composants/EIP; le modèle actuel est volontairement extensible et extrait les structures majeures.
- Pour les repos réels, monter le workspace du runner en lecture seule et cloner un commit dans un répertoire éphémère par campagne.

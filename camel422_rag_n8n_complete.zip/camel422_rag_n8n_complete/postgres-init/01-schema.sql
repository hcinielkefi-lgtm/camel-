CREATE TABLE IF NOT EXISTS knowledge_node (
  node_key       text PRIMARY KEY,
  node_type      text NOT NULL,
  artifact_id    text NOT NULL,
  repository     text,
  module         text,
  source_path    text,
  camel_version  text,
  metadata       jsonb NOT NULL DEFAULT '{}'::jsonb,
  updated_at     timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS knowledge_edge (
  edge_key       text PRIMARY KEY,
  source_key     text NOT NULL,
  target_key     text NOT NULL,
  relation_type  text NOT NULL,
  metadata       jsonb NOT NULL DEFAULT '{}'::jsonb,
  updated_at     timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS knowledge_edge_source_idx ON knowledge_edge(source_key, relation_type);
CREATE INDEX IF NOT EXISTS knowledge_edge_target_idx ON knowledge_edge(target_key, relation_type);
CREATE INDEX IF NOT EXISTS knowledge_node_artifact_idx ON knowledge_node(artifact_id, node_type);

CREATE TABLE IF NOT EXISTS regression_test_catalog (
  test_id            text PRIMARY KEY,
  title              text,
  domain             text,
  provider           text,
  covers_artifacts   text[] NOT NULL DEFAULT '{}',
  tags               text[] NOT NULL DEFAULT '{}',
  project_path       text NOT NULL,
  maven_test         text,
  active             boolean NOT NULL DEFAULT true,
  metadata           jsonb NOT NULL DEFAULT '{}'::jsonb,
  updated_at         timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS regression_run (
  id                  bigserial PRIMARY KEY,
  run_id              text NOT NULL,
  commit_sha          text,
  test_id             text,
  status              text NOT NULL,
  duration_ms         bigint,
  output              jsonb,
  created_at          timestamptz NOT NULL DEFAULT now()
);

INSERT INTO regression_test_catalog(test_id,title,domain,covers_artifacts,tags,project_path,maven_test)
VALUES
('PAYMENT_NORMALIZER_NOMINAL','Normalisation XML nominale','PAYMENT',ARRAY['payment-normalizer','payment-normalize.xsl'],ARRAY['kamelet','xslt','xsd'],'example-camel','PaymentRouteTest#normalizesValidPayment'),
('PAYMENT_NORMALIZER_INVALID_XSD','Rejet XML invalide','PAYMENT',ARRAY['payment-normalizer','payment-input.xsd'],ARRAY['kamelet','xsd','validation'],'example-camel','PaymentRouteTest#rejectsInvalidPayment')
ON CONFLICT(test_id) DO UPDATE SET updated_at=now();

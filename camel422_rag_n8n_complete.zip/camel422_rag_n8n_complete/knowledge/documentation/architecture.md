# Architecture de normalisation
La route payment-entry délègue la validation et la transformation au Kamelet payment-normalizer. Le Kamelet valide payment-input.xsd puis exécute le mapping XSLT 3 payment-normalize.xsl.

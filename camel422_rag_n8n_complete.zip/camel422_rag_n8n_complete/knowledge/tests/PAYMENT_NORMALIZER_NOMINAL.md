# PAYMENT_NORMALIZER_NOMINAL
Couvre: payment-entry, payment-normalizer, payment-normalize.xsl, payment-input.xsd.
Entrée: Payment PAY-001 / 120 EUR / web.
Attendu: CanonicalPayment PAY-001 / 120.00 EUR / WEB.

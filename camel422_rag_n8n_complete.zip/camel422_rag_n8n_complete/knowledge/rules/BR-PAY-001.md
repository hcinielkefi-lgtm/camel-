# BR-PAY-001 — Normalisation des paiements
Tout paiement XML accepté doit contenir Id, Amount avec currency et Channel. Le modèle canonique doit normaliser Channel en majuscules et préserver le montant et sa devise.

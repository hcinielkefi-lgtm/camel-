import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
from app.analyzer import analyze

def read(rel): return (ROOT/'example-camel'/rel).read_text(encoding='utf-8')

def test_kamelet_dependencies():
    r=analyze('kamelets/payment-normalizer.kamelet.yaml',read('src/main/resources/kamelets/payment-normalizer.kamelet.yaml'))
    assert any(d['node_type']=='KAMELET' and d['artifact_id']=='payment-normalizer' for d in r['documents'])
    relations={(e['relation_type'],e['target_key']) for e in r['edges']}
    assert ('USES_XSLT','XSLT:payment-normalize.xsl') in relations
    assert ('USES_COMPONENT','COMPONENT:validator') in relations

def test_xslt_fields():
    r=analyze('mappings/payment-normalize.xsl',read('src/main/resources/mappings/payment-normalize.xsl'))
    d=r['documents'][0]
    assert d['node_type']=='XSLT'
    assert '/Payment' in d['payload']['templates']
    assert 'Amount' in d['payload']['static_outputs']

def test_xsd_root():
    r=analyze('xsd/payment-input.xsd',read('src/main/resources/xsd/payment-input.xsd'))
    assert 'Payment' in r['documents'][0]['payload']['elements']

def test_java_calls_kamelet():
    r=analyze('PaymentRoutes.java',read('src/main/java/com/acme/payment/PaymentRoutes.java'))
    assert any(e['relation_type']=='CALLS_KAMELET' and e['target_key']=='KAMELET:payment-normalizer' for e in r['edges'])

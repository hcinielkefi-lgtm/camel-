from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from typing import Any
from .analyzer import analyze

app=FastAPI(title='Camel 4.22 Knowledge Analyzer',version='1.0.0')
class Request(BaseModel):
    path: str
    content: str
    metadata: dict[str,Any]=Field(default_factory=dict)
@app.get('/health')
def health(): return {'status':'ok','camel_baseline':'4.22.0'}
@app.post('/analyze')
def analyze_endpoint(req: Request):
    try: return analyze(req.path,req.content,req.metadata)
    except Exception as e: raise HTTPException(422,str(e))

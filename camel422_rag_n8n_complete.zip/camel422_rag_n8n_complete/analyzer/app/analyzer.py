from __future__ import annotations
import hashlib, json, re
from pathlib import PurePosixPath
from typing import Any
import yaml
from lxml import etree

XSL = 'http://www.w3.org/1999/XSL/Transform'
XS = 'http://www.w3.org/2001/XMLSchema'

def key(node_type: str, artifact_id: str) -> str:
    return f'{node_type}:{artifact_id}'

def edge(source: str, target: str, relation: str, **meta):
    raw=f'{source}|{relation}|{target}'
    return {'edge_key': hashlib.sha256(raw.encode()).hexdigest(), 'source_key':source,'target_key':target,'relation_type':relation,'metadata':meta}

def doc(node_type: str, artifact_id: str, title: str, text: str, path: str, meta: dict):
    node_key=key(node_type, artifact_id)
    payload={'node_key':node_key,'document_type':node_type,'artifact_id':artifact_id,'title':title,'source_path':path,**meta}
    return {'node_key':node_key,'node_type':node_type,'artifact_id':artifact_id,'title':title,'embedding_text':text,'payload':payload}

def component_of(uri: str) -> str:
    if not uri or ':' not in uri: return 'unknown'
    return uri.split(':',1)[0]

def analyze_yaml(path: str, content: str, base: dict):
    data=yaml.safe_load(content)
    docs=[]; edges=[]
    if not isinstance(data, dict): return docs,edges
    kind=str(data.get('kind','')).upper()
    if kind == 'KAMELET':
        name=(data.get('metadata') or {}).get('name') or PurePosixPath(path).stem.replace('.kamelet','')
        spec=data.get('spec') or {}; definition=spec.get('definition') or {}; template=spec.get('template') or {}
        uris=[]; eips=[]
        def walk(obj):
            if isinstance(obj,dict):
                for k,v in obj.items():
                    if k=='uri' and isinstance(v,str): uris.append(v)
                    elif k not in {'parameters','properties','metadata','definition','template','from','steps'} and isinstance(v,(dict,list)):
                        eips.append(k)
                    walk(v)
            elif isinstance(obj,list):
                for x in obj: walk(x)
        walk(template)
        params=list((definition.get('properties') or {}).keys())
        summary=[f'Kamelet: {name}', f'Parameters: {", ".join(params) or "none"}', 'Endpoints:']+[f'- {u}' for u in uris]
        meta={**base,'kamelet_id':name,'parameters':params,'uris':uris,'eips':sorted(set(eips)),'dependencies':spec.get('dependencies',[])}
        d=doc('KAMELET',name,name,'\n'.join(summary)+'\n\nSOURCE:\n'+content,path,meta); docs.append(d)
        for u in uris:
            comp=component_of(u); target=key('COMPONENT',comp)
            edges.append(edge(d['node_key'],target,'USES_COMPONENT',uri=u))
            docs.append(doc('COMPONENT',comp,comp,f'Apache Camel component: {comp}',path,{**base,'component':comp}))
            if u.startswith('kamelet:') and u not in {'kamelet:source','kamelet:sink'}:
                kid=u.split(':',1)[1].split('?',1)[0].split('/',1)[0]
                edges.append(edge(d['node_key'],key('KAMELET',kid),'CALLS_KAMELET',uri=u))
            if u.startswith('xslt-saxon:') or u.startswith('xslt:'):
                res=u.split(':',1)[1].split('?',1)[0].removeprefix('classpath:')
                edges.append(edge(d['node_key'],key('XSLT',PurePosixPath(res).name),'USES_XSLT',resource=res))
        return _dedupe_docs(docs), _dedupe_edges(edges)
    # Generic Camel YAML DSL
    routes=data if isinstance(data,list) else data.get('routes') or []
    if isinstance(routes,dict): routes=[routes]
    def walk_routes(obj,current='yaml-route'):
        if isinstance(obj,dict):
            for k,v in obj.items():
                if k=='route' and isinstance(v,dict):
                    rid=v.get('id') or current; fromdef=v.get('from') or {}; src=fromdef.get('uri') if isinstance(fromdef,dict) else None
                    uris=[]
                    def collect(x):
                        if isinstance(x,dict):
                            for kk,vv in x.items():
                                if kk=='uri' and isinstance(vv,str): uris.append(vv)
                                collect(vv)
                        elif isinstance(x,list):
                            for xx in x: collect(xx)
                    collect(v)
                    text=f'Camel YAML route {rid}\nSource: {src}\nEndpoints: '+', '.join(uris)+'\n\nSOURCE:\n'+content
                    rd=doc('ROUTE',rid,rid,text,path,{**base,'route_id':rid,'uris':uris}); docs.append(rd)
                    for u in uris:
                        edges.append(edge(rd['node_key'],key('COMPONENT',component_of(u)),'USES_COMPONENT',uri=u))
                        if u.startswith('kamelet:'):
                            kid=u.split(':',1)[1].split('?',1)[0].split('/',1)[0]
                            edges.append(edge(rd['node_key'],key('KAMELET',kid),'CALLS_KAMELET',uri=u))
                walk_routes(v,current)
        elif isinstance(obj,list):
            for x in obj: walk_routes(x,current)
    walk_routes(data)
    return _dedupe_docs(docs),_dedupe_edges(edges)

def analyze_java(path: str, content: str, base: dict):
    docs=[]; edges=[]
    route_ids=re.findall(r'\.routeId\s*\(\s*["\']([^"\']+)',content)
    froms=re.findall(r'\bfrom\s*\(\s*["\']([^"\']+)',content)
    tos=re.findall(r'\btoD?\s*\(\s*["\']([^"\']+)',content)
    beans=re.findall(r'\.bean\s*\(\s*([A-Za-z_$][\w$]*)(?:\.class)?',content)
    processors=re.findall(r'\.process\s*\(\s*(?:new\s+)?([A-Za-z_$][\w$]*)',content)
    rid=route_ids[0] if route_ids else PurePosixPath(path).stem
    uris=froms+tos
    text='\n'.join([f'Camel Java route/class: {rid}',f'From: {", ".join(froms)}',f'To: {", ".join(tos)}',f'Beans: {", ".join(beans)}',f'Processors: {", ".join(processors)}','SOURCE:',content])
    rd=doc('ROUTE',rid,rid,text,path,{**base,'route_id':rid,'from':froms,'to':tos,'beans':beans,'processors':processors});docs.append(rd)
    for u in uris:
        comp=component_of(u); docs.append(doc('COMPONENT',comp,comp,f'Apache Camel component: {comp}',path,{**base,'component':comp}));edges.append(edge(rd['node_key'],key('COMPONENT',comp),'USES_COMPONENT',uri=u))
        if u.startswith('kamelet:'):
            kid=u.split(':',1)[1].split('?',1)[0].split('/',1)[0];edges.append(edge(rd['node_key'],key('KAMELET',kid),'CALLS_KAMELET',uri=u))
    for b in beans: edges.append(edge(rd['node_key'],key('BEAN',b),'USES_BEAN'))
    for p in processors: edges.append(edge(rd['node_key'],key('PROCESSOR',p),'USES_PROCESSOR'))
    for exc in re.findall(r'onException\s*\(\s*([\w.$]+)\.class',content):
        eid=f'{rid}:{exc}'; ed=doc('ERROR_HANDLER',eid,eid,f'Camel onException for {exc} in {rid}',path,{**base,'route_id':rid,'exception':exc});docs.append(ed);edges.append(edge(rd['node_key'],ed['node_key'],'HANDLED_BY'))
    return _dedupe_docs(docs),_dedupe_edges(edges)

def analyze_xslt(path: str, content: str, base: dict):
    root=etree.fromstring(content.encode())
    docs=[];edges=[]; filename=PurePosixPath(path).name
    templates=[]; selects=[]; includes=[]
    for el in root.iter():
        q=etree.QName(el)
        if q.namespace==XSL and q.localname=='template': templates.append(el.get('match') or el.get('name') or '(anonymous)')
        if q.namespace==XSL and q.localname in {'value-of','sequence','apply-templates','for-each','when','if'} and el.get('select'): selects.append(el.get('select'))
        if q.namespace==XSL and q.localname in {'include','import','use-package'} and (el.get('href') or el.get('name')): includes.append(el.get('href') or el.get('name'))
    static_outputs=[]
    for el in root.iter():
        q=etree.QName(el)
        if q.namespace not in {XSL, None} and q.localname: static_outputs.append(q.localname)
        elif q.namespace is None and q.localname not in {'stylesheet','transform'}: static_outputs.append(q.localname)
    summary='\n'.join([f'XSLT 3 mapping: {filename}',f'Templates: {", ".join(templates)}',f'XPath/select expressions: {", ".join(selects)}',f'Includes/imports: {", ".join(includes) or "none"}',f'Static output elements: {", ".join(sorted(set(static_outputs)))}','SOURCE:',content])
    d=doc('XSLT',filename,filename,summary,path,{**base,'xslt_version':root.get('version'),'templates':templates,'selects':selects,'includes':includes,'static_outputs':sorted(set(static_outputs))}); docs.append(d)
    for inc in includes: edges.append(edge(d['node_key'],key('XSLT',PurePosixPath(inc).name),'IMPORTS_XSLT',href=inc))
    return docs,edges

def analyze_xsd(path: str, content: str, base: dict):
    root=etree.fromstring(content.encode()); filename=PurePosixPath(path).name
    ns={'xs':XS}; elements=[x.get('name') for x in root.xpath('./xs:element',namespaces=ns) if x.get('name')]; types=[x.get('name') for x in root.xpath('./xs:complexType|./xs:simpleType',namespaces=ns) if x.get('name')]
    imports=[x.get('schemaLocation') for x in root.xpath('./xs:include|./xs:import',namespaces=ns) if x.get('schemaLocation')]
    text=f'XML Schema: {filename}\nTarget namespace: {root.get("targetNamespace")}\nRoot elements: {", ".join(elements)}\nTypes: {", ".join(types)}\nImports/includes: {", ".join(imports)}\nSOURCE:\n{content}'
    d=doc('XSD',filename,filename,text,path,{**base,'target_namespace':root.get('targetNamespace'),'elements':elements,'types':types,'imports':imports});edges=[]
    for i in imports: edges.append(edge(d['node_key'],key('XSD',PurePosixPath(i).name),'IMPORTS_XSD',href=i))
    return [d],edges

def analyze_xml_dsl(path: str, content: str, base: dict):
    root=etree.fromstring(content.encode());docs=[];edges=[]
    for r in root.xpath('//*[local-name()="route"]'):
        rid=r.get('id') or f'{PurePosixPath(path).stem}-route'
        uris=[x.get('uri') for x in r.xpath('.//*[@uri]') if x.get('uri')]
        d=doc('ROUTE',rid,rid,f'Camel XML route {rid}\nEndpoints: {", ".join(uris)}\nSOURCE:\n{etree.tostring(r,encoding="unicode")}',path,{**base,'route_id':rid,'uris':uris});docs.append(d)
        for u in uris: edges.append(edge(d['node_key'],key('COMPONENT',component_of(u)),'USES_COMPONENT',uri=u))
    return _dedupe_docs(docs),_dedupe_edges(edges)

def analyze_pom(path: str, content: str, base: dict):
    root=etree.fromstring(content.encode()); ns={'m':'http://maven.apache.org/POM/4.0.0'}
    props={etree.QName(x).localname:(x.text or '').strip() for x in root.xpath('./m:properties/*',namespaces=ns)}
    ver=props.get('camel.version') or props.get('camelVersion')
    if not ver:
        vals=root.xpath('.//m:dependency[m:groupId="org.apache.camel" or m:groupId="org.apache.camel.springboot"]/m:version/text()',namespaces=ns); ver=vals[0] if vals else base.get('camel_version','4.22.0')
    aid=(root.findtext('{http://maven.apache.org/POM/4.0.0}artifactId') or PurePosixPath(path).parent.name)
    d=doc('MODULE',aid,aid,f'Maven module {aid}\nApache Camel version: {ver}\nSOURCE:\n{content}',path,{**base,'camel_version':ver,'module':aid})
    return [d],[]

def _dedupe_docs(items):
    out={}
    for x in items: out[x['node_key']]=x
    return list(out.values())
def _dedupe_edges(items):
    return list({x['edge_key']:x for x in items}.values())

def analyze(path: str, content: str, metadata: dict|None=None):
    metadata=metadata or {}; lower=path.lower(); base={'repository':metadata.get('repository'),'module':metadata.get('module'),'commit_sha':metadata.get('commit_sha'),'business_domain':metadata.get('business_domain'),'acl_groups':metadata.get('acl_groups',[]),'camel_version':metadata.get('camel_version','4.22.0')}
    if lower.endswith('.kamelet.yaml') or lower.endswith('.kamelet.yml') or lower.endswith('.yaml') or lower.endswith('.yml'):
        docs,edges=analyze_yaml(path,content,base)
    elif lower.endswith('.java'):
        docs,edges=analyze_java(path,content,base)
    elif lower.endswith(('.xsl','.xslt')):
        docs,edges=analyze_xslt(path,content,base)
    elif lower.endswith('.xsd'):
        docs,edges=analyze_xsd(path,content,base)
    elif lower.endswith('pom.xml'):
        docs,edges=analyze_pom(path,content,base)
    elif lower.endswith('.xml'):
        docs,edges=analyze_xml_dsl(path,content,base)
    else:
        aid=PurePosixPath(path).name; docs=[doc(metadata.get('document_type','DOCUMENTATION'),aid,aid,content,path,base)];edges=[]
    return {'documents':_dedupe_docs(docs),'edges':_dedupe_edges(edges),'stats':{'documents':len(_dedupe_docs(docs)),'edges':len(_dedupe_edges(edges))}}

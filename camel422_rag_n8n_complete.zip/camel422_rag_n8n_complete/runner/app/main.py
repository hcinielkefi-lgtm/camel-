from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from pathlib import Path
import os, subprocess, time, uuid, xml.etree.ElementTree as ET
app=FastAPI(title='Camel Maven Test Runner',version='1.0')
WORKSPACE=Path(os.getenv('RUNNER_WORKSPACE','/workspace')).resolve()
class Req(BaseModel):
    project_path:str='example-camel'
    test:str|None=None
    commit_sha:str|None=None
@app.get('/health')
def health(): return {'status':'ok','workspace':str(WORKSPACE)}
@app.post('/run')
def run(req:Req):
    project=(WORKSPACE/req.project_path).resolve()
    if WORKSPACE not in project.parents and project!=WORKSPACE: raise HTTPException(400,'invalid project path')
    if not (project/'pom.xml').exists(): raise HTTPException(404,'pom.xml not found')
    cmd=['mvn','-B','-ntp','test']
    if req.test: cmd.append(f'-Dtest={req.test}')
    start=time.time(); p=subprocess.run(cmd,cwd=project,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=900)
    tests=failures=errors=skipped=0
    for report in (project/'target/surefire-reports').glob('TEST-*.xml') if (project/'target/surefire-reports').exists() else []:
        try:
            root=ET.parse(report).getroot(); tests+=int(root.get('tests',0)); failures+=int(root.get('failures',0)); errors+=int(root.get('errors',0)); skipped+=int(root.get('skipped',0))
        except Exception: pass
    return {'run_id':str(uuid.uuid4()),'status':'PASS' if p.returncode==0 else 'FAIL','return_code':p.returncode,'duration_ms':int((time.time()-start)*1000),'tests':tests,'failures':failures,'errors':errors,'skipped':skipped,'commit_sha':req.commit_sha,'command':' '.join(cmd),'log_tail':'\n'.join(p.stdout.splitlines()[-120:])}

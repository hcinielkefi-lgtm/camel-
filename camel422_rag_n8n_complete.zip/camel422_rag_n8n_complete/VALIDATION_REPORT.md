# Validation report

Validated in the generation environment on 2026-08-21:

- `python3 scripts/validate_static.py`: PASS
  - all n8n workflow JSON files parse successfully
  - Kamelet YAML parses successfully
  - XML/XSD/XSLT are well-formed XML
- Analyzer unit tests: `4 passed`
  - Kamelet -> XSLT and validator/component dependencies
  - XSLT template/mapping extraction
  - XSD root element extraction
  - Java DSL -> Kamelet dependency extraction
- FastAPI analyzer endpoint: PASS
  - `/health` returns 200
  - `/analyze` returns documents and edges for `payment-normalizer.kamelet.yaml`
- Python byte-code compilation for analyzer and runner: PASS
- `bash -n` for all shell scripts: PASS
- ZIP integrity: PASS

Not executed in the generation environment:

- Apache Camel Maven runtime tests (`mvn test`). The environment has Java 21 but no Maven/Podman and no network path to Maven Central. The pack therefore contains `test-runner`, based on the official Maven `3.9.16-eclipse-temurin-21` image, which runs the tests on the target Podman server.

Target verification command after deployment:

```bash
./scripts/06-test-example.sh
```

Expected result:

- status `PASS`
- 2 tests
- 0 failures
- 0 errors

The example tests are:

1. `PaymentRouteTest#normalizesValidPayment`
2. `PaymentRouteTest#rejectsInvalidPayment`

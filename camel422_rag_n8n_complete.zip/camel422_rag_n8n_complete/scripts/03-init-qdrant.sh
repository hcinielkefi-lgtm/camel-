#!/usr/bin/env bash
set -euo pipefail
set -a; source .env; set +a
AUTH=(); [ -n "${QDRANT_API_KEY:-}" ] && AUTH=(-H "api-key: $QDRANT_API_KEY")
URL=${QDRANT_HOST_URL:-http://127.0.0.1:6333}; C=${QDRANT_COLLECTION:-camel422_knowledge}; D=${EMBEDDING_DIMENSIONS:-1024}
if ! curl -fsS "${AUTH[@]}" "$URL/collections/$C" >/dev/null 2>&1; then curl -fsS -X PUT "${AUTH[@]}" -H 'Content-Type: application/json' "$URL/collections/$C" -d "{\"vectors\":{\"size\":$D,\"distance\":\"Cosine\"},\"on_disk_payload\":true}" | jq .; fi
for f in document_type artifact_id repository module camel_version route_id kamelet_id business_domain incident_id test_id; do curl -fsS -X PUT "${AUTH[@]}" -H 'Content-Type: application/json' "$URL/collections/$C/index?wait=true" -d "{\"field_name\":\"$f\",\"field_schema\":\"keyword\"}" >/dev/null || true; done
echo "Qdrant collection ready: $C"

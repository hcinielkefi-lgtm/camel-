#!/usr/bin/env bash
set -euo pipefail
URL=${INGEST_URL:-http://127.0.0.1:5678/webhook/camel-rag-ingest}
ingest(){ local f=$1; jq -n --arg path "$f" --rawfile content "$f" '{path:$path,content:$content,metadata:{repository:"camel422-example",module:"payment",camel_version:"4.22.0",business_domain:"PAYMENT",acl_groups:["PAYMENT_DEV"]}}' | curl -fsS -H 'Content-Type: application/json' -d @- "$URL" | jq .; }
find example-camel/src/main knowledge -type f \( -name '*.java' -o -name '*.yaml' -o -name '*.yml' -o -name '*.xsl' -o -name '*.xslt' -o -name '*.xsd' -o -name '*.xml' -o -name '*.md' \) -print0 | while IFS= read -r -d '' f; do echo "== $f"; ingest "$f"; done

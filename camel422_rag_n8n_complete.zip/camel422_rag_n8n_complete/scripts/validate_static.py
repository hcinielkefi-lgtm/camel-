from pathlib import Path
import json,sys,yaml
from lxml import etree
root=Path(__file__).resolve().parents[1]
errors=[]
for p in (root/'workflows').glob('*.json'):
    try: json.loads(p.read_text())
    except Exception as e: errors.append(f'{p}: {e}')
for p in (root/'example-camel').rglob('*.yaml'):
    try: yaml.safe_load(p.read_text())
    except Exception as e: errors.append(f'{p}: {e}')
for ext in ('*.xml','*.xsd','*.xsl'):
    for p in (root/'example-camel').rglob(ext):
        try: etree.parse(str(p))
        except Exception as e: errors.append(f'{p}: {e}')
if errors:
    print('\n'.join(errors)); sys.exit(1)
print('STATIC_VALIDATION_OK')

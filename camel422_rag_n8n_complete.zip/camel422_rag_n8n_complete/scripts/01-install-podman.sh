#!/usr/bin/env bash
set -euo pipefail
if command -v apt-get >/dev/null; then sudo apt-get update && sudo apt-get install -y podman podman-compose curl jq openssl; elif command -v dnf >/dev/null; then sudo dnf install -y podman podman-compose curl jq openssl; else echo 'Install Podman, podman-compose, curl, jq, openssl'; exit 1; fi
podman --version
podman info --format '{{.Host.CgroupsVersion}}'

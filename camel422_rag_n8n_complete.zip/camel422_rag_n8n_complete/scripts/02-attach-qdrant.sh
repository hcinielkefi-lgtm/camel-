#!/usr/bin/env bash
set -euo pipefail
C=${QDRANT_CONTAINER:-qdrant}; podman network exists rag-net || podman network create rag-net
podman container exists "$C" || { echo "Qdrant container $C not found"; exit 2; }
podman network connect --alias qdrant rag-net "$C" 2>/dev/null || true
echo "Qdrant attached to rag-net"

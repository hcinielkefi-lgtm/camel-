#!/usr/bin/env bash
set -euo pipefail
curl -fsS http://127.0.0.1:5678/webhook/camel-regression-run -H 'Content-Type: application/json' -d '{"project_path":"example-camel"}' | jq .

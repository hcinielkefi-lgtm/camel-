#!/usr/bin/env bash
set -euo pipefail
[ -f .env ] || { cp .env.example .env; echo 'Configure .env first'; exit 2; }
grep -q CHANGE_ME .env && { echo 'Replace CHANGE_ME in .env'; exit 2; }
podman network exists rag-net || podman network create rag-net
podman compose -f podman-compose.yml up -d --build
set -a; source .env; set +a
podman exec camel-rag-ollama ollama pull "$OLLAMA_EMBED_MODEL"
podman exec camel-rag-ollama ollama pull "$OLLAMA_LLM_MODEL"
podman ps --format 'table {{.Names}}\t{{.Status}}'

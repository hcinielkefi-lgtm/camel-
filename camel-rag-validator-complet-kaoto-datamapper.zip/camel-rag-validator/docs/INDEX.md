# Index de documentation

Ce répertoire regroupe la documentation fonctionnelle et technique du projet.

## Documents

- `CATALOGUE.md` — catalogue des EIP, DSL et familles de composants Apache Camel 4 couvertes ou prévues.
- `MESSAGING.md` — IBM MQ / MQSeries, Kafka, sécurité, DLQ et pont MQ ↔ Kafka.
- `ORACLE_REST_ENRICHMENT.md` — enrichissement Oracle SQL + API REST, paramètres, sécurité et exemples.
- `XPATH_LOOPS.md` — XPath complexes, namespaces, Saxon, Split XPath et boucles conditionnelles avancées.
- `KAOTO_DATAMAPPER_XSLT.md` — DataMapper Kaoto, schémas multi-fichiers et transformation XSLT 3.0 complexe.
- `VALIDATION.md` — corrections apportées à la version initiale et points de validation.

## Profils Spring

| Profil | But |
|---|---|
| aucun | Démo locale sans infrastructure externe, H2 + routes Camel locales |
| `messaging` | IBM MQ + Kafka |
| `messaging,kafka-secure` | IBM MQ + Kafka avec SASL/SSL Kafka |
| `enrichment` | Oracle + API REST externe |
| `messaging,enrichment` | MQ + Kafka + Oracle + REST |

## Scripts

- `scripts/run-local.sh`
- `scripts/run-messaging.sh`
- `scripts/run-enrichment.sh`
- `scripts/run-all.sh`
- `scripts/verify.sh`

## Configuration

- `.env.example` : vue globale de toutes les variables d'environnement.
- `.env.messaging.example` : variables spécifiques MQ/Kafka.
- `.env.enrichment.example` : variables spécifiques Oracle/REST.

Les secrets réels ne doivent jamais être committés.

# Catalogue Apache Camel 4 — couverture et extensions

Ce document sert d'index pour un corpus RAG/validation. `[x]` = exemple présent dans le projet ; `[opt]` = exemple présent mais désactivé par défaut ; `[catalogue]` = extension à ajouter avec l'infrastructure correspondante.

## EIP / routage

- [x] Message Channel : Direct / SEDA
- [x] Content-Based Router : Choice
- [x] Message Filter : Filter
- [x] Splitter
- [x] Aggregator
- [x] Multicast
- [x] Scatter-Gather
- [x] Recipient List
- [x] Routing Slip
- [x] Dynamic Router
- [x] Dynamic To (`toD`)
- [x] Wire Tap
- [x] Content Enricher / Poll Enrich
- [x] Claim Check
- [x] Sort
- [x] Resequencer batch
- [x] Validate
- [x] Idempotent Consumer
- [x] Load Balancer Round Robin / Weighted / Failover
- [x] Throttler
- [x] Delayer
- [x] Loop
- [x] Stop
- [x] Threads
- [x] Sample
- [x] Step
- [x] Route Template
- [x] Kamelet
- [x] Saga
- [x] Transactional Client (JDBC local)
- [x] Circuit Breaker / Fallback
- [x] Throw Exception / Rollback
- [x] OnCompletion
- [x] Route Configuration
- [x] Control Bus
- [catalogue] Service Call / service discovery
- [catalogue] Resumable Consumer
- [catalogue] Stream resequencer
- [catalogue] Batch Consumer avancé
- [catalogue] Custom RoutePolicy / SupervisingRouteController
- [catalogue] Custom UnitOfWork / Synchronization
- [catalogue] XA/JTA distribuée
- [catalogue] LRA durable pour Saga distribuée

## Message / transformation

- [x] Set/Remove Header
- [x] Exchange Property
- [x] Exchange Variable
- [x] Processor
- [x] Bean
- [x] Type conversion
- [x] Simple
- [x] JSON Jackson
- [x] JSONPath
- [x] XSLT Saxon
- [x] Kaoto DataMapper / XSLT 3.0 complexe
- [x] Schémas XSD multi-fichiers pour DataMapper (`xs:import`)
- [x] XSD Validator
- [x] XPath avancé / Saxon
- [catalogue] XQuery
- [catalogue] JQ
- [catalogue] CSV
- [catalogue] Bindy
- [catalogue] JAXB marshal/unmarshal
- [catalogue] Avro / Protobuf
- [catalogue] Parquet
- [catalogue] Base64 / crypto / XML security
- [catalogue] Zip / Tar

## Erreurs / résilience

- [x] Dead Letter Channel
- [x] Redelivery
- [x] Exponential backoff
- [x] `onException`
- [x] `doTry/doCatch/doFinally`
- [x] `useOriginalMessage`
- [x] Circuit Breaker Resilience4j
- [x] Fallback
- [x] Rollback transactionnel par exception
- [catalogue] ExceptionPolicyStrategy personnalisée
- [catalogue] Dead letter persistante via broker
- [catalogue] Retry Topics Kafka

## API / transports

- [x] REST DSL / platform-http
- [x] HTTP client starter
- [x] OpenAPI / Springdoc
- [opt] REST OpenAPI contract-first client
- [x] File
- [x] SQL / JDBC
- [x] Timer
- [opt] Kafka
- [opt] SFTP
- [catalogue] FTP / FTPS
- [catalogue] JMS / ActiveMQ / Artemis
- [catalogue] AMQP
- [catalogue] RabbitMQ
- [catalogue] MQTT
- [catalogue] WebSocket
- [catalogue] gRPC
- [catalogue] SOAP / CXF
- [catalogue] GraphQL
- [catalogue] Mail / IMAP / SMTP
- [catalogue] Netty

## Data stores / enterprise

- [x] H2 local
- [catalogue] PostgreSQL / MySQL / Oracle / SQL Server
- [catalogue] JPA
- [catalogue] MongoDB
- [catalogue] Cassandra
- [catalogue] Redis
- [catalogue] Elasticsearch / OpenSearch
- [catalogue] LDAP
- [catalogue] Salesforce
- [catalogue] SAP

## Cloud

- [catalogue] AWS2 S3 / SQS / SNS / Lambda / Kinesis / DynamoDB / Secrets Manager
- [catalogue] Azure Storage / Service Bus / Event Hubs / Key Vault
- [catalogue] Google Pub/Sub / Storage / BigQuery / Secret Manager
- [catalogue] Kubernetes

## IA / RAG

- [opt] OpenAI Chat Completion
- [opt] OpenAI Embeddings
- [catalogue] LangChain4j
- [catalogue] Vector stores
- [catalogue] AI Tool / tool calling
- [catalogue] ingestion documents -> chunking -> embeddings -> vector store -> retrieval -> prompt
- [catalogue] garde-fous, filtrage PII, citations et évaluation RAG

## DSL / packaging

- [x] Java DSL
- [x] XML IO DSL
- [x] YAML DSL
- [x] Route Template Java
- [x] Route Template YAML
- [x] Kamelet classpath
- [catalogue] Endpoint DSL
- [catalogue] Component DSL
- [catalogue] Camel Main standalone
- [catalogue] Quarkus
- [catalogue] Camel K

## Observabilité / production

- [x] Actuator
- [x] Micrometer
- [x] Prometheus registry
- [x] JMX
- [x] Message History
- [x] Step EIP pour métriques groupées
- [x] Control Bus (status)
- [x] frontière de confiance `removeHeaders("Camel*")`
- [catalogue] OpenTelemetry tracing
- [catalogue] Micrometer tracing
- [catalogue] Health checks custom
- [catalogue] TLS / mTLS
- [catalogue] OAuth2 / OIDC selon transport
- [catalogue] Vault / secret manager
- [catalogue] Docker / Compose
- [catalogue] Kubernetes probes / ConfigMaps / Secrets

## Tests

- [x] Spring Boot context
- [x] ProducerTemplate
- [x] assertions AssertJ
- [x] transactions commit/rollback
- [x] XML/YAML DSL
- [x] Kamelet
- [catalogue] MockEndpoint
- [catalogue] AdviceWith
- [catalogue] NotifyBuilder
- [catalogue] Testcontainers (Kafka, PostgreSQL, Artemis, SFTP...)
- [catalogue] contract tests OpenAPI
- [catalogue] chaos / failure injection

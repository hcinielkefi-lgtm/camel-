# Corrections appliquées par rapport au script initial

## Build / versions

- Alignement Apache Camel **4.22.0 LTS** avec le BOM Spring Boot Camel.
- Parent Spring Boot **4.1.0**, aligné avec la branche Camel 4.22.
- Java **17** conservé.
- Starters Spring Boot Camel sous `org.apache.camel.springboot`.
- Tests JUnit 5 via `spring-boot-starter-test`; pas de dépendance `camel-test-spring` obsolète.

## REST

- Remplacement du composant `servlet` non configuré par `platform-http`.
- Ajout de consommateurs `direct:` réels pour les opérations REST.
- Ajout de GET `/api/orders`, POST `/api/orders`, GET `/api/orders/{id}`.
- Contrat `openapi.yaml` cohérent avec ces routes.
- Exemple `rest-openapi` conditionnel pour le contract-first.

## SQL / transactions

- Remplacement de `ON CONFLICT DO NOTHING`, non portable avec le mode H2 initial, par `MERGE INTO ... KEY(...)`.
- Ajout d'un `DataSourceTransactionManager`.
- Test de commit et de rollback transactionnel.

## Saga

- Ajout explicite de `InMemorySagaService` pour que l'exemple Saga dispose d'un `CamelSagaService`.
- Ajout des routes `bookProduct`, `processPayment`, `updateInventory`, compensation et completion.

## XML / YAML / Kamelet

- Chargement explicite des routes externes via `camel.main.routes-include-pattern`.
- YAML DSL en camelCase Camel 4 (`setBody`, `setHeader`, `routeTemplate`).
- Kamelet au format `spec.template`, sous `classpath:kamelets`.

## Robustesse

- Dead Letter Channel, redelivery/backoff et `useOriginalMessage`.
- `onException` métier.
- `doTry/doCatch/doFinally` local.
- Circuit Breaker Resilience4j avec fallback.
- Route Configuration réutilisable.

## Sécurité / exploitation

- Connecteurs externes désactivés par défaut.
- Secrets OpenAI externalisés via variables d'environnement.
- Exemple `removeHeaders("Camel*")` à une frontière de confiance.
- Actuator, Micrometer, Prometheus, JMX et Control Bus.

## Limite volontaire

Le projet ne démarre pas automatiquement Kafka, SFTP, OpenAI ni les services cloud. Ces intégrations sont opt-in afin que le contexte local puisse démarrer sans Docker, broker ni credential externe.

## Kaoto DataMapper / XSLT 3.0 (v2.2)

Ajouts validés statiquement :

- XSLT 3.0 bien formé ;
- schéma source `order-source.xsd` compilable avec ses `xs:import` ;
- XML d'entrée valide contre le schéma source ;
- schéma cible `fulfillment-target.xsd` compilable ;
- XML attendu valide contre le schéma cible ;
- YAML Kaoto/Camel syntaxiquement valide ;
- dépendances POM restaurées pour JMS/IBM MQ et Oracle ;
- `camel-jackson3-starter` utilisé pour Camel 4.22 ;
- `camel-xpath-starter` explicitement ajouté.

Le runtime XSLT 3.0 n'a pas été exécuté dans cet environnement car Maven/Saxon CLI n'y sont pas disponibles localement. `mvn clean verify` reste la validation finale à effectuer sur une machine disposant de Maven et d'un accès aux dépôts de dépendances.

# XPath complexes et boucles conditionnelles — Camel 4.22

Ce module complète le catalogue avec des exemples XML plus proches de cas d'intégration réels.

## Dépendances

Le projet charge maintenant :

- `camel-xpath-starter` pour le langage XPath ;
- `camel-saxon-starter` pour les fonctions XPath 2.0 utilisées dans l'exemple Saxon.

Les routes se trouvent dans :

`src/main/java/com/example/camel/routes/AdvancedXPathLoopRouteBuilder.java`

XML de démonstration :

`src/main/resources/samples/advanced-order.xml`

Tests :

`src/test/java/com/example/camel/AdvancedXPathLoopRoutesTest.java`

## Namespaces utilisés

```text
o -> urn:example:orders
c -> urn:example:customer
p -> urn:example:product
```

En Java DSL ils sont regroupés dans un `Namespaces` réutilisable :

```java
private static final Namespaces NS = new Namespaces("o", "urn:example:orders")
    .add("c", "urn:example:customer")
    .add("p", "urn:example:product");
```

## 1. XPath complexe de classification

Endpoint : `direct:xpathAdvanced`

La règle combine :

- attributs ;
- plusieurs namespaces ;
- `count()` ;
- `sum()` ;
- `not()` ;
- prédicats imbriqués ;
- conditions `and` / `or` ;
- extraction avec résultat typé ;
- `choice/when/otherwise`.

Exemple de prédicat :

```xpath
/o:order[
    @priority='HIGH'
    and c:customer/@segment='VIP'
    and count(o:lines/o:line[@active='true']) >= 2
    and sum(o:lines/o:line[@active='true']/@lineTotal) >= 1000
    and not(o:flags/o:flag[@code='BLOCKED'])
]
```

Résultats ajoutés aux headers :

```text
customerId
currency
lineCount
activeAmount
classification
```

`classification` peut être :

```text
VIP_HIGH_VALUE
SPECIAL_HANDLING
STANDARD
```

## 2. Headers / properties Camel utilisés comme variables XPath

Endpoint : `direct:xpathVariables`

Le prédicat :

```xpath
sum(/o:order/o:lines/o:line[@active='true']/@lineTotal) >= number($threshold)
and $region = 'EU'
and not(/o:order/o:flags/o:flag[@code='BLOCKED'])
```

`$threshold` et `$region` sont résolus à partir du contexte Camel.

Exemple :

```java
producerTemplate.requestBodyAndHeaders(
    "direct:xpathVariables",
    xml,
    Map.of("threshold", 1000, "region", "EU")
);
```

## 3. XPath 2.0 avec Saxon

Endpoint : `direct:xpathSaxon`

Exemple :

```xpath
string-join(
    distinct-values(/o:order/o:lines/o:line/p:product/@category),
    ','
)
```

Cela permet par exemple d'obtenir :

```text
STANDARD,PREMIUM
```

Le projet active Saxon uniquement sur cette expression avec `XPathBuilder.saxon()` plutôt que globalement.

## 4. Split XPath pour parcourir des nœuds

Endpoint : `direct:xpathSplitLines`

```xpath
/o:order/o:lines/o:line[@active='true']
```

Chaque nœud `<o:line>` devient temporairement le body d'un sous-Exchange. Une règle secondaire classe ensuite chaque ligne :

```xpath
/*[local-name()='line'][
    @hazardous='true'
    or number(@lineTotal) >= 500
]
```

Exemple de résultat agrégé :

```text
SKU-001:STANDARD|SKU-002:REVIEW
```

### Pourquoi Split et non Loop ?

`loop` répète un Exchange N fois. `split(xpath(...))` parcourt une collection de nœuds. Pour traiter chaque élément XML sélectionné par XPath, `split` est généralement le bon EIP.

## 5. Nombre de boucles calculé par XPath

Endpoint : `direct:loopXPathCount`

Le nombre d'itérations vient directement du XML :

```xpath
number(/o:order/@repetitions)
```

Pour :

```xml
<o:order repetitions="3" ...>
```

la propriété Camel `CamelLoopIndex` prend successivement :

```text
0
1
2
```

Le résultat de démonstration est :

```text
0,1,2,
```

## 6. `loopDoWhile` avancé

Endpoint : `direct:loopDoWhileAdvanced`

La condition combine XML et état Camel :

```xpath
$continueProcessing = true()
and number($attempt) < number(/o:order/@maxAttempts)
```

Sources :

- `maxAttempts` : XML ;
- `$attempt` : header Camel ;
- `$continueProcessing` : Exchange Property ;
- `succeedAt` : header métier utilisé pour la simulation ;
- `BLOCKED` : flag XML pouvant arrêter la boucle.

À chaque itération, un `choice` imbriqué peut produire :

```text
BLOCKED
SUCCESS
RETRY
MAX_ATTEMPTS
```

Exemple :

```java
Exchange result = producerTemplate.request("direct:loopDoWhileAdvanced", e -> {
    e.getMessage().setBody(xml);
    e.getMessage().setHeader("succeedAt", 3);
});
```

Avec `maxAttempts="5"`, la boucle s'arrête à la troisième tentative et produit :

```text
attempt-1;attempt-2;attempt-3;
```

avec :

```text
loopOutcome = SUCCESS
```

## 7. Exemple XML DSL

Exemple de boucle pilotée par XPath :

```xml
<route id="xml-xpath-loop-example">
    <from uri="direct:xmlXpathLoopExample"/>
    <loop>
        <xpath>number(/order/@times)</xpath>
        <log message="Iteration ${exchangeProperty.CamelLoopIndex}"/>
    </loop>
</route>
```

Exemple de do/while :

```xml
<loop doWhile="true">
    <simple>${header.retry} == true</simple>
    <to uri="direct:tryAgain"/>
</loop>
```

## 8. Exemple YAML DSL

```yaml
- route:
    id: yaml-conditional-loop-example
    from:
      uri: direct:yamlConditionalLoopExample
      steps:
        - loop:
            doWhile: "true"
            expression:
              simple:
                expression: "${header.retry} == true"
            steps:
              - log:
                  message: "Iteration ${exchangeProperty.CamelLoopIndex}"
              - to:
                  uri: direct:tryAgain
```

## Bonnes pratiques

1. Borner toutes les boucles pilotées par des données externes.
2. Ne pas utiliser `loop` pour parcourir une collection XML : utiliser `split(xpath(...))`.
3. Activer le stream caching ou convertir le body en `String` lorsqu'un flux XML doit être évalué plusieurs fois.
4. Déclarer explicitement les namespaces plutôt que d'utiliser systématiquement `local-name()`.
5. Utiliser `local-name()` surtout aux frontières où le préfixe XML n'est pas maîtrisé.
6. Utiliser un `resultType` explicite pour les résultats XPath destinés à des headers métiers.
7. Pour un `NODESET` traité en parallèle, activer la sécurité thread de XPath ou convertir/copier les nœuds avant traitement parallèle.
8. Garder les règles XPath très volumineuses dans des ressources externes ou une couche de règles dédiée.
9. Préférer Saxon lorsqu'une fonction XPath 2.0 est réellement nécessaire ; ne pas l'activer sans besoin sur toutes les expressions.
10. Prévoir une condition de sortie métier et une limite technique maximale pour tout `loopDoWhile`.

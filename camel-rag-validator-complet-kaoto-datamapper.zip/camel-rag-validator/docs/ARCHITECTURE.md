# Architecture du projet

## Vue logique

```text
                         +--------------------+
                         |   REST DSL / HTTP  |
                         +---------+----------+
                                   |
                                   v
+-----------+              +-------+--------+              +-------------+
| IBM MQ    |<------------>| Routes Camel 4 |<------------>| Kafka       |
| MQSeries  |              | EIP / Services |              | Topics/DLQ  |
+-----------+              +-------+--------+              +-------------+
                                   |
                    +--------------+---------------+
                    |                              |
                    v                              v
             +------+-------+              +-------+-------+
             | Oracle SQL   |              | API REST      |
             | enrichment   |              | enrichment    |
             +------+-------+              +-------+-------+
                    |                              |
                    +--------------+---------------+
                                   |
                                   v
                         +---------+----------+
                         | Message enrichi    |
                         +--------------------+
```

## Packages Java

- `config/` : DataSource H2/Oracle, IBM MQ JMS, transactions et Route Configuration.
- `controller/` : façade HTTP pour scénarios de démonstration.
- `model/` : DTO / modèles métier.
- `processor/` : Processor Camel personnalisés.
- `routes/` : RouteBuilder classés par famille fonctionnelle.
- `service/` : beans utilisés par les EIP.
- `strategy/` : stratégies d'agrégation et d'enrichissement.

## Ressources

- `camel/` : XML DSL et YAML DSL.
- `kamelets/` : Kamelets réutilisables.
- `sql/` : schéma H2 et requêtes Oracle externalisées.
- `openapi.yaml` : exemple contract-first.
- `order.xsd` : validation XML.
- `transform.xsl` : transformation XSLT.

## Principe d'activation

Les dépendances externes sont présentes dans le build, mais leurs routes/configurations sont protégées par `@ConditionalOnProperty`. Le projet démarre donc sans IBM MQ, Kafka, Oracle ou API REST tant que les profils/propriétés correspondants ne sont pas activés.


## XML / XPath avancé

`AdvancedXPathLoopRouteBuilder` regroupe les scénarios XPath complexes : namespaces, variables Camel, Saxon, Split XPath, boucles pilotées par XPath et `loopDoWhile` conditionnel. Voir `XPATH_LOOPS.md`.

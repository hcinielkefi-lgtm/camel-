package com.example.camel;

import static org.assertj.core.api.Assertions.assertThat;

import org.apache.camel.ProducerTemplate;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class ManagementRoutesTest {
    @Autowired ProducerTemplate producerTemplate;

    @Test
    void stepGroupsProcessing() {
        var exchange = producerTemplate.request("direct:stepDemo", e -> e.getMessage().setBody("x"));
        assertThat(exchange.getMessage().getBody(String.class)).isEqualTo("STEP:x");
        assertThat(exchange.getMessage().getHeader("normalized", Boolean.class)).isTrue();
        assertThat(exchange.getMessage().getHeader("afterStep", Boolean.class)).isTrue();
    }

    @Test
    void routeConfigurationHandlesConfiguredException() {
        var exchange = producerTemplate.request("direct:routeConfigurationDemo", e -> {
            e.getMessage().setBody("x");
            e.getMessage().setHeader("fail", true);
        });
        assertThat(exchange.getMessage().getHeader("routeConfigurationHandled", Boolean.class)).isTrue();
        assertThat(exchange.getMessage().getBody(String.class)).contains("configured failure");
    }

    @Test
    void controlBusReturnsRouteStatus() {
        String status = producerTemplate.requestBody("direct:routeStatus", null, String.class);
        assertThat(status).containsIgnoringCase("Started");
    }
}

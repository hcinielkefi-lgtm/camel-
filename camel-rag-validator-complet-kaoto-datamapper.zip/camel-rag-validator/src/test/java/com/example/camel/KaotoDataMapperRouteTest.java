package com.example.camel;

import java.nio.charset.StandardCharsets;

import org.apache.camel.ProducerTemplate;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
class KaotoDataMapperRouteTest {

    @Autowired
    ProducerTemplate producerTemplate;

    @Test
    void shouldTransformComplexXmlWithKaotoStyleXslt() throws Exception {
        String input;
        try (var stream = getClass().getResourceAsStream("/kaoto/datamapper/samples/order-input.xml")) {
            assertThat(stream).isNotNull();
            input = new String(stream.readAllBytes(), StandardCharsets.UTF_8);
        }

        var exchange = producerTemplate.request("direct:kaotoDataMapperXslt", e -> {
            e.getMessage().setBody(input);
            e.getMessage().setHeader("sourceSystem", "KAOTO-DEMO");
            e.getMessage().setHeader("correlationId", "CORR-1001");
            e.getMessage().setHeader("exchangeRate", "1.10");
        });

        String output = exchange.getMessage().getBody(String.class);
        assertThat(exchange.getMessage().getHeader("kaotoDataMapperValidated", Boolean.class)).isTrue();
        assertThat(output).contains("<f:PriorityCode>P1</f:PriorityCode>");
        assertThat(output).contains("<f:DisplayName>CLIENT EXEMPLE</f:DisplayName>");
        assertThat(output).contains("<f:ConvertedTotal>1265.00</f:ConvertedTotal>");
        assertThat(output).contains("<f:Categories>PREMIUM,STANDARD</f:Categories>");
        assertThat(output.indexOf("SKU-002")).isLessThan(output.indexOf("SKU-001"));
    }
}

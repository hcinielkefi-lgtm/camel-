package com.example.camel;

import static org.assertj.core.api.Assertions.assertThat;

import org.apache.camel.CamelContext;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class ApplicationContextTest {
    @Autowired CamelContext camelContext;

    @Test
    void contextLoadsAndRoutesArePresent() {
        assertThat(camelContext).isNotNull();
        assertThat(camelContext.getRoutes()).isNotEmpty();
    }
}

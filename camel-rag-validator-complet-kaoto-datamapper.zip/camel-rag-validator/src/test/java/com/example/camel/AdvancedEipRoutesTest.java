package com.example.camel;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;
import org.apache.camel.ProducerTemplate;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class AdvancedEipRoutesTest {
    @Autowired ProducerTemplate producerTemplate;

    @Test
    void dynamicRouterVisitsAllSteps() {
        String result = producerTemplate.requestBody("direct:dynamicRouter", "x", String.class);
        assertThat(result).isEqualTo("x-A-B-C");
    }

    @Test
    void claimCheckRestoresOriginalBody() {
        String result = producerTemplate.requestBody("direct:claimCheck", "sensitive", String.class);
        assertThat(result).isEqualTo("sensitive");
    }

    @Test
    void sortOrdersTokens() {
        Object result = producerTemplate.requestBody("direct:sort", "c,a,b");
        assertThat(result).isInstanceOf(List.class);
        assertThat((List<?>) result).containsExactly("a", "b", "c");
    }

    @Test
    void toDUsesDynamicEndpoint() {
        String result = producerTemplate.requestBody("direct:toD", "x", String.class);
        assertThat(result).isEqualTo("x-C");
    }
    @Test
    void scatterGatherAggregatesReplies() {
        String result = producerTemplate.requestBody("direct:scatterGather", "x", String.class);
        assertThat(result).contains("A:x", "B:x", "C:x");
    }

    @Test
    void trustBoundaryRemovesCamelHeaders() {
        var exchange = producerTemplate.request("direct:trustBoundary", e -> {
            e.getMessage().setBody("x");
            e.getMessage().setHeader("CamelHttpUri", "https://attacker.invalid");
            e.getMessage().setHeader("businessHeader", "keep");
        });
        assertThat(exchange.getMessage().getHeader("CamelHttpUri")).isNull();
        assertThat(exchange.getMessage().getHeader("businessHeader")).isEqualTo("keep");
    }

}

package com.example.camel;

import static org.assertj.core.api.Assertions.assertThat;

import com.example.camel.strategy.SectionEnrichmentAggregationStrategy;
import java.util.Map;
import org.apache.camel.CamelContext;
import org.apache.camel.Exchange;
import org.apache.camel.support.DefaultExchange;
import org.junit.jupiter.api.Test;
import org.apache.camel.impl.DefaultCamelContext;

class SectionEnrichmentAggregationStrategyTest {

    @Test
    void keepsOriginalPayloadAndAddsSection() {
        CamelContext context = new DefaultCamelContext();
        Exchange original = new DefaultExchange(context);
        original.getMessage().setBody(Map.of("payload", "order"));

        Exchange resource = new DefaultExchange(context);
        resource.getMessage().setBody(Map.of("customerId", "C1", "segment", "GOLD"));

        Exchange result = new SectionEnrichmentAggregationStrategy("oracleCustomer")
            .aggregate(original, resource);

        @SuppressWarnings("unchecked")
        Map<String, Object> body = result.getMessage().getBody(Map.class);
        assertThat(body.get("payload")).isEqualTo("order");
        assertThat(body.get("oracleCustomer")).isEqualTo(Map.of("customerId", "C1", "segment", "GOLD"));
    }
}

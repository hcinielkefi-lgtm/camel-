package com.example.camel;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.math.BigDecimal;
import java.util.Map;
import org.apache.camel.ProducerTemplate;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class DatabaseTransactionTest {
    @Autowired ProducerTemplate producerTemplate;
    @Autowired JdbcTemplate jdbcTemplate;

    @Test
    void transactionCommits() {
        producerTemplate.requestBodyAndHeaders("direct:transact", "", Map.of(
            "id", "TX-OK", "amount", new BigDecimal("12.50"), "productId", "P001", "quantity", 2
        ));
        Integer count = jdbcTemplate.queryForObject("select count(*) from orders where id='TX-OK'", Integer.class);
        assertThat(count).isEqualTo(1);
    }

    @Test
    void transactionRollsBack() {
        assertThatThrownBy(() -> producerTemplate.requestBodyAndHeaders("direct:transact", "", Map.of(
            "id", "TX-KO", "amount", new BigDecimal("8.00"), "productId", "P001", "quantity", 1, "forceRollback", true
        ))).isInstanceOf(Exception.class);
        Integer count = jdbcTemplate.queryForObject("select count(*) from orders where id='TX-KO'", Integer.class);
        assertThat(count).isZero();
    }
}

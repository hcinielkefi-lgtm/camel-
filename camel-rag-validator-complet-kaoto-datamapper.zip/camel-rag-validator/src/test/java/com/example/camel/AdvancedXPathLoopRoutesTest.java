package com.example.camel;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.Map;
import org.apache.camel.Exchange;
import org.apache.camel.ProducerTemplate;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class AdvancedXPathLoopRoutesTest {

    private static final String XML = """
        <o:order xmlns:o="urn:example:orders"
                 xmlns:c="urn:example:customer"
                 xmlns:p="urn:example:product"
                 currency="EUR" priority="HIGH" repetitions="3" maxAttempts="5">
          <c:customer id="C00042" segment="VIP"/>
          <o:lines>
            <o:line active="true" lineTotal="250" hazardous="false">
              <p:product sku="SKU-001" category="STANDARD"/>
            </o:line>
            <o:line active="true" lineTotal="900" hazardous="false">
              <p:product sku="SKU-002" category="PREMIUM"/>
            </o:line>
            <o:line active="false" lineTotal="50" temperatureControlled="true">
              <p:product sku="SKU-003" category="STANDARD"/>
            </o:line>
          </o:lines>
          <o:flags><o:flag code="MANUAL_REVIEW"/></o:flags>
        </o:order>
        """;

    @Autowired
    ProducerTemplate producerTemplate;

    @Test
    void complexXPathExtractsAndClassifies() {
        Exchange result = producerTemplate.request("direct:xpathAdvanced", e -> e.getMessage().setBody(XML));

        assertThat(result.getMessage().getHeader("customerId")).isEqualTo("C00042");
        assertThat(result.getMessage().getHeader("currency")).isEqualTo("EUR");
        assertThat(result.getMessage().getHeader("lineCount", Double.class)).isEqualTo(3.0);
        assertThat(result.getMessage().getHeader("activeAmount", Double.class)).isEqualTo(1150.0);
        assertThat(result.getMessage().getHeader("classification")).isEqualTo("VIP_HIGH_VALUE");
    }

    @Test
    void xpathCanReadCamelHeadersAsVariables() {
        Exchange result = producerTemplate.request("direct:xpathVariables", e -> {
            e.getMessage().setBody(XML);
            e.getMessage().setHeaders(Map.of("threshold", 1000, "region", "EU"));
        });

        assertThat(result.getMessage().getHeader("eligible", Boolean.class)).isTrue();
    }

    @Test
    void saxonXPathUsesXpath2Functions() {
        String result = producerTemplate.requestBody("direct:xpathSaxon", XML, String.class);
        assertThat(result).contains("STANDARD", "PREMIUM");
    }

    @Test
    void splitXpathProcessesSelectedNodes() {
        String result = producerTemplate.requestBody("direct:xpathSplitLines", XML, String.class);
        assertThat(result).isEqualTo("SKU-001:STANDARD|SKU-002:REVIEW");
    }

    @Test
    void loopCountComesFromXpath() {
        String result = producerTemplate.requestBody("direct:loopXPathCount", XML, String.class);
        assertThat(result).isEqualTo("0,1,2,");
    }

    @Test
    void doWhileStopsImmediatelyWhenXmlIsBlocked() {
        String blockedXml = XML.replace("MANUAL_REVIEW", "BLOCKED");

        Exchange result = producerTemplate.request("direct:loopDoWhileAdvanced", e -> {
            e.getMessage().setBody(blockedXml);
            e.getMessage().setHeader("succeedAt", 4);
        });

        assertThat(result.getMessage().getBody(String.class)).isEqualTo("attempt-1;");
        assertThat(result.getMessage().getHeader("loopOutcome")).isEqualTo("BLOCKED");
    }

    @Test
    void doWhileStopsWhenBusinessTargetIsReached() {
        Exchange result = producerTemplate.request("direct:loopDoWhileAdvanced", e -> {
            e.getMessage().setBody(XML);
            e.getMessage().setHeader("succeedAt", 3);
        });

        assertThat(result.getMessage().getBody(String.class)).isEqualTo("attempt-1;attempt-2;attempt-3;");
        assertThat(result.getMessage().getHeader("attempt", Integer.class)).isEqualTo(3);
        assertThat(result.getMessage().getHeader("loopOutcome")).isEqualTo("SUCCESS");
    }
}

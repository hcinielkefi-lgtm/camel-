package com.example.camel;

import static org.assertj.core.api.Assertions.assertThat;

import org.apache.camel.ProducerTemplate;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class CoreRoutesTest {
    @Autowired ProducerTemplate producerTemplate;

    @Test
    void transformRouteWorks() {
        String result = producerTemplate.requestBody("direct:transform", "hello camel", String.class);
        assertThat(result).isEqualTo("BEAN_TRANSFORM: PROCESSED: HELLO CAMEL");
    }

    @Test
    void routingSlipWorks() {
        String result = producerTemplate.requestBody("direct:routingSlip", "x", String.class);
        assertThat(result).isEqualTo("x-A-B-C");
    }

    @Test
    void yamlAndXmlRoutesLoad() {
        assertThat(producerTemplate.requestBody("direct:xmlDemo", "Camel", String.class)).contains("XML matched");
        assertThat(producerTemplate.requestBody("direct:yamlDemo", "Camel", String.class)).contains("YAML matched");
    }
    @Test
    void fileKameletLoadsFromClasspath() {
        String result = producerTemplate.requestBody("direct:kameletFileDemo", "hello", String.class);
        assertThat(result).isEqualTo("FILE-KAMELET:hello");
    }

}

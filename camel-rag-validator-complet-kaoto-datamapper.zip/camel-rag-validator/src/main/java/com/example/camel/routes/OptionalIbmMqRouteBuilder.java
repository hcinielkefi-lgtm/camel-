package com.example.camel.routes;

import jakarta.jms.JMSException;
import org.apache.camel.Exchange;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

@Component
@ConditionalOnProperty(name = "demo.ibm-mq.enabled", havingValue = "true")
public class OptionalIbmMqRouteBuilder extends RouteBuilder {

    @Override
    public void configure() {
        onException(JMSException.class)
            .maximumRedeliveries(5)
            .redeliveryDelay(1000)
            .useExponentialBackOff()
            .backOffMultiplier(2.0)
            .retryAttemptedLogLevel(LoggingLevel.WARN)
            .handled(false);

        // Consumer IBM MQ -> traitement Camel local.
        from("ibmmq:queue:{{demo.ibm-mq.input-queue}}"
                + "?concurrentConsumers={{demo.ibm-mq.concurrent-consumers}}"
                + "&maxConcurrentConsumers={{demo.ibm-mq.max-concurrent-consumers}}"
                + "&cacheLevelName=CACHE_CONSUMER"
                + "&bridgeErrorHandler=true")
            .routeId("ibm-mq-consumer")
            .setHeader("integrationTransport", constant("ibm-mq"))
            .setHeader("integrationSource", simple("${header.JMSDestination}"))
            .log("IBM MQ <- JMSMessageID=${header.JMSMessageID}, body=${body}")
            .to("direct:mqInbound");

        from("direct:mqInbound")
            .routeId("ibm-mq-inbound-processing")
            .setHeader("mqProcessed", constant(true))
            .to("seda:messagingAudit");

        // Producer Camel -> IBM MQ.
        from("direct:mqSend")
            .routeId("ibm-mq-producer")
            .removeHeaders("Camel*")
            .setHeader("integrationTransport", constant("ibm-mq"))
            .to("ibmmq:queue:{{demo.ibm-mq.output-queue}}"
                + "?deliveryPersistent=true&jmsMessageType=Text");

        // Request/Reply JMS. Le service distant doit répondre via JMSReplyTo.
        from("direct:mqRequestReply")
            .routeId("ibm-mq-request-reply")
            .removeHeaders("Camel*")
            .to("ibmmq:queue:{{demo.ibm-mq.output-queue}}"
                + "?exchangePattern=InOut"
                + "&requestTimeout={{demo.ibm-mq.request-timeout-ms}}"
                + "&jmsMessageType=Text");

        // Exemple d'envoi applicatif explicite vers une DLQ IBM MQ.
        from("direct:mqDlq")
            .routeId("ibm-mq-dlq-producer")
            .setHeader(Exchange.CONTENT_TYPE, constant("text/plain"))
            .to("ibmmq:queue:{{demo.ibm-mq.dlq}}?deliveryPersistent=true");

        from("seda:messagingAudit")
            .routeId("messaging-audit")
            .log("Messaging audit transport=${header.integrationTransport} body=${body}");
    }
}

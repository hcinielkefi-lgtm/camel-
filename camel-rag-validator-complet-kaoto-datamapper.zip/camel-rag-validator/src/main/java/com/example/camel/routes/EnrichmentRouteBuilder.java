package com.example.camel.routes;

import com.example.camel.strategy.EnrichmentAggregationStrategy;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

@Component
public class EnrichmentRouteBuilder extends RouteBuilder {
    @Override
    public void configure() {
        from("direct:enrich")
            .routeId("enrich-producer")
            .enrich("direct:lookup", new EnrichmentAggregationStrategy());

        from("direct:lookup")
            .routeId("enrich-lookup")
            .setBody(constant("lookup-data"));

        from("direct:pollEnrich")
            .routeId("poll-enrich")
            .pollEnrich("seda:enrichment-cache", 100)
            .choice()
                .when(body().isNull())
                    .setBody(constant("no-enrichment-available"))
            .end();

        from("direct:seedEnrichment")
            .routeId("seed-enrichment")
            .to("seda:enrichment-cache");
    }
}

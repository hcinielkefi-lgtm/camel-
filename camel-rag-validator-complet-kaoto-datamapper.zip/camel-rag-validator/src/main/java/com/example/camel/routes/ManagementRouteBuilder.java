package com.example.camel.routes;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

@Component
public class ManagementRouteBuilder extends RouteBuilder {
    @Override
    public void configure() {
        // Step: regroupe plusieurs processeurs en une unité logique observable.
        from("direct:stepDemo")
            .routeId("step-demo")
            .step("normalization-step")
                .setHeader("normalized", constant(true))
                .setBody(simple("STEP:${body}"))
            .end()
            .setHeader("afterStep", constant(true));

        // Control Bus: lecture de l'état d'une route connue, sans commande arbitraire.
        from("direct:routeStatus")
            .routeId("controlbus-status")
            .to("controlbus:route?routeId=core-transform&action=status");

        // Rollback EIP: démonstration explicite de l'arrêt/rollback logique.
        from("direct:rollbackDemo")
            .routeId("rollback-demo")
            .choice()
                .when(body().contains("ROLLBACK"))
                    .rollback("Rollback requested by message")
                .otherwise()
                    .setBody(simple("accepted:${body}"))
            .end();
    }
}

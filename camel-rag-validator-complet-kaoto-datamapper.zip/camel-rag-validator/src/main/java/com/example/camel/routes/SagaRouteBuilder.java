package com.example.camel.routes;

import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.saga.InMemorySagaService;
import org.springframework.stereotype.Component;

@Component
public class SagaRouteBuilder extends RouteBuilder {
    @Override
    public void configure() throws Exception {
        getContext().addService(new InMemorySagaService());

        from("direct:sagaOrder")
            .routeId("saga-order")
            .saga()
                .option("id", header("orderId"))
                .compensation("direct:cancelOrder")
                .completion("direct:completeOrder")
            .to("direct:bookProduct")
            .to("direct:processPayment")
            .to("direct:updateInventory");

        from("direct:bookProduct")
            .routeId("saga-book-product")
            .log("Book product for ${header.orderId}");

        from("direct:processPayment")
            .routeId("saga-payment")
            .choice()
                .when(header("failPayment").isEqualTo(true))
                    .throwException(new IllegalStateException("payment refused"))
                .otherwise()
                    .log("Payment accepted for ${header.orderId}")
            .end();

        from("direct:updateInventory")
            .routeId("saga-inventory")
            .log("Inventory updated for ${header.orderId}");

        from("direct:cancelOrder")
            .routeId("saga-cancel")
            .setBody(simple("CANCELLED:${header.orderId}"))
            .to("file:data/saga/cancel?fileName=${header.orderId}.txt");

        from("direct:completeOrder")
            .routeId("saga-complete")
            .setBody(simple("COMPLETED:${header.orderId}"))
            .to("file:data/saga/complete?fileName=${header.orderId}.txt");
    }
}

package com.example.camel.routes;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

@Component
@ConditionalOnProperty(name = "demo.openapi-client.enabled", havingValue = "true")
public class OptionalOpenApiClientRouteBuilder extends RouteBuilder {
    @Override
    public void configure() {
        from("direct:openapiGetOrders")
            .routeId("optional-rest-openapi-client")
            .to("rest-openapi:classpath:openapi.yaml#getOrders"
                + "?host={{demo.openapi-client.host}}&componentName=http");
    }
}

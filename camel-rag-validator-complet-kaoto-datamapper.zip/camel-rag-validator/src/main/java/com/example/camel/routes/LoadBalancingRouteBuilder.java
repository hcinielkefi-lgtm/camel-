package com.example.camel.routes;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

@Component
public class LoadBalancingRouteBuilder extends RouteBuilder {
    @Override
    public void configure() {
        from("direct:roundRobin")
            .routeId("lb-round-robin")
            .loadBalance().roundRobin()
                .to("direct:node1")
                .to("direct:node2")
                .to("direct:node3")
            .end();

        from("direct:weighted")
            .routeId("lb-weighted")
            .loadBalance().weighted("4,2,1")
                .to("direct:node1")
                .to("direct:node2")
                .to("direct:node3")
            .end();

        from("direct:failover")
            .routeId("lb-failover")
            .loadBalance().failover()
                .to("direct:alwaysFail")
                .to("direct:node2")
            .end();

        from("direct:node1").routeId("lb-node1").setBody(simple("node1:${body}"));
        from("direct:node2").routeId("lb-node2").setBody(simple("node2:${body}"));
        from("direct:node3").routeId("lb-node3").setBody(simple("node3:${body}"));
        from("direct:alwaysFail").routeId("lb-failing-node").throwException(new IllegalStateException("node unavailable"));
    }
}

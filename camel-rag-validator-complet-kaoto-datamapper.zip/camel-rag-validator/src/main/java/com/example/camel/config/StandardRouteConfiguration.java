package com.example.camel.config;

import org.apache.camel.builder.RouteConfigurationBuilder;
import org.springframework.stereotype.Component;

@Component
public class StandardRouteConfiguration extends RouteConfigurationBuilder {
    @Override
    public void configuration() {
        routeConfiguration("standard-errors")
            .onException(UnsupportedOperationException.class)
                .handled(true)
                .setHeader("routeConfigurationHandled", constant(true))
                .setBody(simple("route-config-handled:${exception.message}"));
    }
}

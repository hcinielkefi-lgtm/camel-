package com.example.camel.service;

import org.springframework.stereotype.Component;

@Component("myBean")
public class MyBean {
    public String transform(String input) {
        return "BEAN_TRANSFORM: " + input.toUpperCase();
    }

    public String enrich(String input) {
        return input + " | enriched-by-bean";
    }
}

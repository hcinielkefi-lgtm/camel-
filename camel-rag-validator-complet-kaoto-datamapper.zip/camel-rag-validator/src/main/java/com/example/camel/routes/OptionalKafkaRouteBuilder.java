package com.example.camel.routes;

import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

@Component
@ConditionalOnProperty(name = "demo.kafka.enabled", havingValue = "true")
public class OptionalKafkaRouteBuilder extends RouteBuilder {

    @Override
    public void configure() {
        onException(Exception.class)
            .maximumRedeliveries(3)
            .redeliveryDelay(1000)
            .useExponentialBackOff()
            .backOffMultiplier(2.0)
            .retryAttemptedLogLevel(LoggingLevel.WARN)
            .handled(true)
            .useOriginalMessage()
            .to("kafka:{{demo.kafka.dlq-topic}}");

        // Consumer Kafka. Brokers, sécurité et groupe sont configurés au niveau
        // camel.component.kafka.* dans application.properties / variables d'environnement.
        from("kafka:{{demo.kafka.input-topic}}?consumersCount={{demo.kafka.consumers-count}}")
            .routeId("kafka-consumer")
            .setHeader("integrationTransport", constant("kafka"))
            .log("Kafka <- topic=${header.CamelKafkaTopic}, partition=${header.CamelKafkaPartition}, offset=${header.CamelKafkaOffset}, body=${body}")
            .to("direct:kafkaInbound");

        from("direct:kafkaInbound")
            .routeId("kafka-inbound-processing")
            .setHeader("kafkaProcessed", constant(true))
            .to("seda:kafkaAudit");

        // Producer Camel -> topic de sortie.
        from("direct:kafkaSend")
            .routeId("kafka-producer")
            .removeHeaders("Camel*")
            .setHeader("integrationTransport", constant("kafka"))
            .to("kafka:{{demo.kafka.output-topic}}");

        // Producteur dynamique : le header kafkaTargetTopic choisit le topic.
        // A utiliser uniquement avec une liste de topics validée par l'application.
        from("direct:kafkaSendDynamic")
            .routeId("kafka-dynamic-producer")
            .validate(header("kafkaTargetTopic").isNotNull())
            .toD("kafka:${header.kafkaTargetTopic}");

        from("seda:kafkaAudit")
            .routeId("kafka-audit")
            .log("Kafka audit body=${body}");
    }
}

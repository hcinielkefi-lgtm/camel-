package com.example.camel.routes;

import com.example.camel.strategy.SectionEnrichmentAggregationStrategy;
import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

@Component
@ConditionalOnProperty(
    name = {"demo.enrichment.enabled", "demo.oracle.enabled", "demo.enrichment.api.enabled"},
    havingValue = "true"
)
public class OptionalCompositeEnrichmentRouteBuilder extends RouteBuilder {

    @Override
    public void configure() {
        from("direct:enrichCustomerExternal")
            .routeId("customer-external-enrichment")
            .validate(header("customerId").isNotNull())
            .process(exchange -> {
                Object original = exchange.getMessage().getBody();
                Map<String, Object> envelope = new LinkedHashMap<>();
                envelope.put("customerId", exchange.getMessage().getHeader("customerId"));
                envelope.put("payload", original);
                envelope.put("enrichmentStartedAt", Instant.now().toString());
                exchange.getMessage().setBody(envelope);
            })
            .enrich("direct:oracleCustomer", new SectionEnrichmentAggregationStrategy("oracleCustomer"))
            .enrich("direct:oracleCustomerSummary", new SectionEnrichmentAggregationStrategy("oracleSummary"))
            .enrich("direct:oracleCustomerContracts", new SectionEnrichmentAggregationStrategy("oracleContracts"))
            .enrich("direct:restCustomer", new SectionEnrichmentAggregationStrategy("remoteCustomer"))
            .enrich("direct:restRiskScore", new SectionEnrichmentAggregationStrategy("risk"))
            .process(exchange -> {
                @SuppressWarnings("unchecked")
                Map<String, Object> body = exchange.getMessage().getBody(Map.class);
                body.put("enrichmentCompletedAt", Instant.now().toString());
                body.put("enriched", true);
            });
    }
}

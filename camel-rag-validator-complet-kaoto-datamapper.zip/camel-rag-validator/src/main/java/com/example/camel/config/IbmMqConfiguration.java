package com.example.camel.config;

import com.ibm.mq.jakarta.jms.MQConnectionFactory;
import com.ibm.msg.jakarta.client.wmq.WMQConstants;
import jakarta.jms.ConnectionFactory;
import jakarta.jms.JMSException;
import org.apache.camel.component.jms.JmsComponent;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConditionalOnProperty(name = "demo.ibm-mq.enabled", havingValue = "true")
public class IbmMqConfiguration {

    @Bean(name = "ibmMqConnectionFactory")
    ConnectionFactory ibmMqConnectionFactory(
            @Value("${demo.ibm-mq.host}") String host,
            @Value("${demo.ibm-mq.port}") int port,
            @Value("${demo.ibm-mq.queue-manager}") String queueManager,
            @Value("${demo.ibm-mq.channel}") String channel,
            @Value("${demo.ibm-mq.application-name}") String applicationName,
            @Value("${demo.ibm-mq.ssl-cipher-suite:}") String sslCipherSuite) throws JMSException {

        MQConnectionFactory factory = new MQConnectionFactory();
        factory.setIntProperty(WMQConstants.WMQ_CONNECTION_MODE, WMQConstants.WMQ_CM_CLIENT);
        factory.setStringProperty(WMQConstants.WMQ_HOST_NAME, host);
        factory.setIntProperty(WMQConstants.WMQ_PORT, port);
        factory.setStringProperty(WMQConstants.WMQ_QUEUE_MANAGER, queueManager);
        factory.setStringProperty(WMQConstants.WMQ_CHANNEL, channel);
        factory.setStringProperty(WMQConstants.WMQ_APPLICATIONNAME, applicationName);

        if (sslCipherSuite != null && !sslCipherSuite.isBlank()) {
            factory.setSSLCipherSuite(sslCipherSuite);
        }
        return factory;
    }

    /**
     * Composant Camel nommé "ibmmq". Les routes peuvent donc utiliser :
     * ibmmq:queue:MA.QUEUE ou ibmmq:topic:MON.TOPIC.
     */
    @Bean(name = "ibmmq")
    JmsComponent ibmMqComponent(
            @Qualifier("ibmMqConnectionFactory") ConnectionFactory connectionFactory,
            @Value("${demo.ibm-mq.username:}") String username,
            @Value("${demo.ibm-mq.password:}") String password) {

        JmsComponent component = JmsComponent.jmsComponentAutoAcknowledge(connectionFactory);
        if (username != null && !username.isBlank()) {
            component.setUsername(username);
        }
        if (password != null && !password.isBlank()) {
            component.setPassword(password);
        }
        // L'activation du profil ne doit pas rendre le boot impossible pendant
        // une courte indisponibilité réseau. Le consumer gère ensuite la reconnexion.
        component.setTestConnectionOnStartup(false);
        component.setAsyncStartListener(true);
        return component;
    }
}

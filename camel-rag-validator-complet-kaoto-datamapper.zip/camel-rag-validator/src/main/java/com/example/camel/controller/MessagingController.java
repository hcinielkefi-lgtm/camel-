package com.example.camel.controller;

import java.util.Map;
import org.apache.camel.ProducerTemplate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/messaging")
public class MessagingController {

    private final ProducerTemplate producerTemplate;
    private final boolean mqEnabled;
    private final boolean kafkaEnabled;
    private final boolean bridgeEnabled;

    public MessagingController(
            ProducerTemplate producerTemplate,
            @Value("${demo.ibm-mq.enabled:false}") boolean mqEnabled,
            @Value("${demo.kafka.enabled:false}") boolean kafkaEnabled,
            @Value("${demo.messaging.bridge-enabled:false}") boolean bridgeEnabled) {
        this.producerTemplate = producerTemplate;
        this.mqEnabled = mqEnabled;
        this.kafkaEnabled = kafkaEnabled;
        this.bridgeEnabled = bridgeEnabled;
    }

    @GetMapping("/status")
    public Map<String, Object> status() {
        return Map.of(
            "ibmMqEnabled", mqEnabled,
            "kafkaEnabled", kafkaEnabled,
            "bridgeEnabled", bridgeEnabled
        );
    }

    @PostMapping(value = "/mq", consumes = "text/plain")
    public ResponseEntity<?> sendMq(@RequestBody String body) {
        if (!mqEnabled) {
            return disabled("IBM MQ");
        }
        producerTemplate.sendBody("direct:mqSend", body);
        return ResponseEntity.accepted().body(Map.of("sent", true, "transport", "ibm-mq"));
    }

    @PostMapping(value = "/mq/request-reply", consumes = "text/plain")
    public ResponseEntity<?> requestReplyMq(@RequestBody String body) {
        if (!mqEnabled) {
            return disabled("IBM MQ");
        }
        Object response = producerTemplate.requestBody("direct:mqRequestReply", body);
        return ResponseEntity.ok(Map.of("transport", "ibm-mq", "response", response == null ? "" : response));
    }

    @PostMapping(value = "/kafka", consumes = "text/plain")
    public ResponseEntity<?> sendKafka(@RequestBody String body) {
        if (!kafkaEnabled) {
            return disabled("Kafka");
        }
        producerTemplate.sendBody("direct:kafkaSend", body);
        return ResponseEntity.accepted().body(Map.of("sent", true, "transport", "kafka"));
    }

    private ResponseEntity<Map<String, Object>> disabled(String connector) {
        return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE)
            .body(Map.of("sent", false, "error", connector + " connector is disabled"));
    }
}

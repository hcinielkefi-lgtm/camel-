package com.example.camel.strategy;

import org.apache.camel.AggregationStrategy;
import org.apache.camel.Exchange;

public class EnrichmentAggregationStrategy implements AggregationStrategy {
    @Override
    public Exchange aggregate(Exchange original, Exchange resource) {
        if (resource == null) {
            return original;
        }
        String left = original.getMessage().getBody(String.class);
        String right = resource.getMessage().getBody(String.class);
        original.getMessage().setBody(left + " + " + right);
        return original;
    }
}

package com.example.camel.routes;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

@Component
@ConditionalOnProperty(name = "demo.sftp.enabled", havingValue = "true")
public class OptionalSftpRouteBuilder extends RouteBuilder {
    @Override
    public void configure() {
        from("sftp://{{demo.sftp.host}}:{{demo.sftp.port}}/{{demo.sftp.directory}}"
            + "?username={{demo.sftp.username}}&password={{demo.sftp.password}}&delete=false")
            .routeId("optional-sftp-consumer")
            .to("file:data/sftp-downloads");
    }
}

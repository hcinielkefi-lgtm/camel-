package com.example.camel.model;

import java.math.BigDecimal;

public record Order(String id, BigDecimal amount, String productId, Integer quantity, String status) {
    public Order withStatus(String newStatus) {
        return new Order(id, amount, productId, quantity, newStatus);
    }
}

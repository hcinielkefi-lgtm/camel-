package com.example.camel.config;

import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

@Configuration
public class LocalDataSourceConfiguration {

    @Bean(name = "dataSource")
    @Primary
    DataSource localDataSource(
        @Value("${spring.datasource.url}") String url,
        @Value("${spring.datasource.driver-class-name}") String driverClassName,
        @Value("${spring.datasource.username}") String username,
        @Value("${spring.datasource.password:}") String password
    ) {
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setDriverClassName(driverClassName);
        dataSource.setUrl(url);
        dataSource.setUsername(username);
        dataSource.setPassword(password);
        return dataSource;
    }
}

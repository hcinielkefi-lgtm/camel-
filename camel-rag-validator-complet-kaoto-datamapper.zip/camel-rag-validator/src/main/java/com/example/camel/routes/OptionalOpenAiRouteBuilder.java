package com.example.camel.routes;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

@Component
@ConditionalOnProperty(name = "demo.openai.enabled", havingValue = "true")
public class OptionalOpenAiRouteBuilder extends RouteBuilder {
    @Override
    public void configure() {
        from("direct:aiChat")
            .routeId("optional-openai-chat")
            .to("openai:chat-completion");

        from("direct:aiEmbeddings")
            .routeId("optional-openai-embeddings")
            .to("openai:embeddings");
    }
}

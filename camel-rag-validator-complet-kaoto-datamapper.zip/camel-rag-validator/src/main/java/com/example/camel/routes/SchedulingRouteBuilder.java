package com.example.camel.routes;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

@Component
public class SchedulingRouteBuilder extends RouteBuilder {
    @Override
    public void configure() {
        from("timer:heartbeat?period=30000")
            .routeId("timer-heartbeat")
            .setBody(simple("heartbeat-${date:now:yyyy-MM-dd'T'HH:mm:ss}"))
            .log("${body}");
    }
}

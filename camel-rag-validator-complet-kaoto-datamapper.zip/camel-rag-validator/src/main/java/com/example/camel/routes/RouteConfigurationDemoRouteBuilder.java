package com.example.camel.routes;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

@Component
public class RouteConfigurationDemoRouteBuilder extends RouteBuilder {
    @Override
    public void configure() {
        from("direct:routeConfigurationDemo")
            .routeId("route-configuration-demo")
            .routeConfigurationId("standard-errors")
            .choice()
                .when(header("fail").isEqualTo(true))
                    .throwException(new UnsupportedOperationException("configured failure"))
                .otherwise()
                    .setBody(simple("route-config-ok:${body}"))
            .end();
    }
}

package com.example.camel.routes;

import java.util.LinkedHashMap;
import java.util.Map;
import org.apache.camel.Exchange;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

@Component
@ConditionalOnProperty(name = "demo.enrichment.api.enabled", havingValue = "true")
public class OptionalRestEnrichmentRouteBuilder extends RouteBuilder {
    private final String authType;
    private final String token;
    private final String apiKey;
    private final String apiKeyHeader;

    public OptionalRestEnrichmentRouteBuilder(
        @Value("${demo.enrichment.api.auth-type:none}") String authType,
        @Value("${demo.enrichment.api.token:}") String token,
        @Value("${demo.enrichment.api.api-key:}") String apiKey,
        @Value("${demo.enrichment.api.api-key-header:X-API-Key}") String apiKeyHeader
    ) {
        this.authType = authType;
        this.token = token;
        this.apiKey = apiKey;
        this.apiKeyHeader = apiKeyHeader;
    }

    @Override
    public void configure() {
        from("direct:restCustomer")
            .routeId("rest-enrichment-customer-get")
            .validate(header("customerId").isNotNull())
            .removeHeaders("CamelHttp*")
            .setHeader(Exchange.HTTP_METHOD, constant("GET"))
            .setHeader("Accept", constant("application/json"))
            .process(this::applyAuthentication)
            .toD("{{demo.enrichment.api.base-url}}/customers/${header.customerId}"
                + "?throwExceptionOnFailure=false"
                + "&connectTimeout={{demo.enrichment.api.connect-timeout-ms}}"
                + "&responseTimeout={{demo.enrichment.api.response-timeout-ms}}")
            .to("direct:classifyRestEnrichmentResponse");

        from("direct:restRiskScore")
            .routeId("rest-enrichment-risk-post")
            .validate(header("customerId").isNotNull())
            .removeHeaders("CamelHttp*")
            .process(exchange -> {
                Map<String, Object> request = new LinkedHashMap<>();
                request.put("customerId", exchange.getMessage().getHeader("customerId"));
                request.put("countryCode", exchange.getMessage().getHeader("countryCode"));
                request.put("requestedBy", "camel-rag-validator");
                exchange.getMessage().setBody(request);
            })
            .marshal().json(JsonLibrary.Jackson)
            .setHeader(Exchange.HTTP_METHOD, constant("POST"))
            .setHeader(Exchange.CONTENT_TYPE, constant("application/json"))
            .setHeader("Accept", constant("application/json"))
            .process(this::applyAuthentication)
            .toD("{{demo.enrichment.api.base-url}}/risk/evaluate"
                + "?throwExceptionOnFailure=false"
                + "&connectTimeout={{demo.enrichment.api.connect-timeout-ms}}"
                + "&responseTimeout={{demo.enrichment.api.response-timeout-ms}}")
            .to("direct:classifyRestEnrichmentResponse");

        from("direct:classifyRestEnrichmentResponse")
            .routeId("rest-enrichment-classify-response")
            .convertBodyTo(String.class)
            .process(exchange -> {
                Integer status = exchange.getMessage().getHeader(Exchange.HTTP_RESPONSE_CODE, Integer.class);
                String response = exchange.getMessage().getBody(String.class);
                exchange.setProperty("enrichmentHttpStatus", status);
                exchange.setProperty("enrichmentHttpResponse", response);

                if (status == null) {
                    throw new IllegalStateException("API REST sans code HTTP");
                }
                if (status == 404) {
                    exchange.getMessage().setHeader("enrichmentResponseKind", "not-found");
                } else if (status == 429 || status >= 500) {
                    exchange.getMessage().setHeader("enrichmentResponseKind", "server-error");
                } else if (status >= 200 && status < 300) {
                    exchange.getMessage().setHeader(
                        "enrichmentResponseKind",
                        response == null || response.isBlank() ? "success-empty" : "success-json"
                    );
                } else {
                    exchange.getMessage().setHeader("enrichmentResponseKind", "client-error");
                }
            })
            .choice()
                .when(header("enrichmentResponseKind").isEqualTo("success-json"))
                    .unmarshal().json(JsonLibrary.Jackson, Map.class)
                .when(header("enrichmentResponseKind").isEqualTo("success-empty"))
                    .process(exchange -> exchange.getMessage().setBody(Map.of(
                        "httpStatus", exchange.getProperty("enrichmentHttpStatus")
                    )))
                .when(header("enrichmentResponseKind").isEqualTo("not-found"))
                    .setBody(constant(Map.of("found", false, "httpStatus", 404)))
                .when(header("enrichmentResponseKind").isEqualTo("server-error"))
                    .process(exchange -> {
                        Object status = exchange.getProperty("enrichmentHttpStatus");
                        throw new IllegalStateException("API REST indisponible, HTTP " + status);
                    })
                .otherwise()
                    .process(exchange -> {
                        Object status = exchange.getProperty("enrichmentHttpStatus");
                        String response = exchange.getProperty("enrichmentHttpResponse", String.class);
                        Map<String, Object> error = new LinkedHashMap<>();
                        error.put("error", "remote-api-error");
                        error.put("httpStatus", status);
                        error.put("response", response == null ? "" : response);
                        exchange.getMessage().setBody(error);
                    })
            .end()
            .removeHeader("enrichmentResponseKind");
    }

    private void applyAuthentication(Exchange exchange) {
        if ("bearer".equalsIgnoreCase(authType) && !token.isBlank()) {
            exchange.getMessage().setHeader("Authorization", "Bearer " + token);
        } else if ("api-key".equalsIgnoreCase(authType) && !apiKey.isBlank()) {
            exchange.getMessage().setHeader(apiKeyHeader, apiKey);
        }
    }
}

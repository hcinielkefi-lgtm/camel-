package com.example.camel.strategy;

import org.apache.camel.AggregationStrategy;
import org.apache.camel.Exchange;

public class StringAggregationStrategy implements AggregationStrategy {
    @Override
    public Exchange aggregate(Exchange oldExchange, Exchange newExchange) {
        if (oldExchange == null) {
            return newExchange;
        }
        String oldBody = oldExchange.getMessage().getBody(String.class);
        String newBody = newExchange.getMessage().getBody(String.class);
        oldExchange.getMessage().setBody(oldBody + "|" + newBody);
        return oldExchange;
    }
}

package com.example.camel.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.springframework.stereotype.Component;

@Component("myProcessor")
public class MyProcessor implements Processor {
    @Override
    public void process(Exchange exchange) {
        String body = exchange.getMessage().getBody(String.class);
        exchange.getMessage().setHeader("processedBy", "MyProcessor");
        exchange.setProperty("startTime", System.currentTimeMillis());
        exchange.setVariable("audit", "processor-called");
        exchange.getMessage().setBody("PROCESSED: " + body);
    }
}

package com.example.camel.routes;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

@Component
public class TemplateAndKameletRouteBuilder extends RouteBuilder {
    @Override
    public void configure() {
        routeTemplate("uppercaseTemplate")
            .templateParameter("source")
            .templateParameter("target")
            .from("{{source}}")
                .setBody(simple("${body.toUpperCase()}"))
                .to("{{target}}");

        routeTemplate("setMyBody")
            .templateParameter("bodyValue")
            .from("kamelet:source")
                .setBody(constant("{{bodyValue}}"));

        from("direct:kameletDemo")
            .routeId("kamelet-demo")
            .to("kamelet:setMyBody?bodyValue=myKamelet");

        from("direct:kameletFileDemo")
            .routeId("kamelet-file-demo")
            .to("kamelet:my-kamelet?message=FILE-KAMELET");
    }
}

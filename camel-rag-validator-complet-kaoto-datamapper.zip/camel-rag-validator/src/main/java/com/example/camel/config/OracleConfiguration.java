package com.example.camel.config;

import java.sql.SQLException;
import javax.sql.DataSource;
import oracle.jdbc.pool.OracleDataSource;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConditionalOnProperty(name = "demo.oracle.enabled", havingValue = "true")
public class OracleConfiguration {

    @Bean(name = "oracleDataSource")
    DataSource oracleDataSource(
        @Value("${demo.oracle.url}") String url,
        @Value("${demo.oracle.username}") String username,
        @Value("${demo.oracle.password}") String password
    ) throws SQLException {
        OracleDataSource dataSource = new OracleDataSource();
        dataSource.setURL(url);
        dataSource.setUser(username);
        dataSource.setPassword(password);
        return dataSource;
    }
}

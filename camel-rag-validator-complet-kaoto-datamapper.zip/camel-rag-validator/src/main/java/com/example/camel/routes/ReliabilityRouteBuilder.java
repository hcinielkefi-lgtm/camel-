package com.example.camel.routes;

import java.util.concurrent.atomic.AtomicInteger;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.support.processor.idempotent.MemoryIdempotentRepository;
import org.springframework.stereotype.Component;

@Component
public class ReliabilityRouteBuilder extends RouteBuilder {
    private final AtomicInteger flakyCounter = new AtomicInteger();

    @Override
    public void configure() {
        errorHandler(deadLetterChannel("seda:dead-letter")
            .useOriginalMessage()
            .maximumRedeliveries(3)
            .redeliveryDelay(100)
            .useExponentialBackOff()
            .backOffMultiplier(2));

        onException(IllegalArgumentException.class)
            .handled(true)
            .maximumRedeliveries(0)
            .setHeader("errorType", constant("business"))
            .setBody(simple("Invalid argument: ${exception.message}"));

        from("seda:dead-letter")
            .routeId("dead-letter-consumer")
            .log("DLQ body=${body}, exception=${exception.message}");

        from("direct:triggerBusinessError")
            .routeId("business-error")
            .throwException(new IllegalArgumentException("business validation failed"));

        from("direct:localTryCatch")
            .routeId("local-try-catch")
            .doTry()
                .process(e -> { throw new NullPointerException("local NPE"); })
            .doCatch(NullPointerException.class)
                .setBody(constant("caught-locally"))
            .doFinally()
                .setHeader("cleanup", constant(true))
            .end();

        from("direct:idempotent")
            .routeId("idempotent-consumer")
            .idempotentConsumer(header("messageId"), MemoryIdempotentRepository.memoryIdempotentRepository(1000))
                .skipDuplicate(true)
                .setBody(simple("accepted:${body}"))
            .end();

        from("direct:circuitBreaker")
            .routeId("resilience4j-circuit-breaker")
            .circuitBreaker()
                .resilience4jConfiguration()
                    .failureRateThreshold(50)
                    .minimumNumberOfCalls(2)
                    .slidingWindowSize(4)
                    .waitDurationInOpenState(1000)
                .end()
                .to("direct:flaky")
            .onFallback()
                .setBody(constant("fallback"))
            .end();

        from("direct:flaky")
            .routeId("flaky-service")
            .process(e -> {
                if (flakyCounter.incrementAndGet() % 2 == 1) {
                    throw new IllegalStateException("simulated downstream failure");
                }
                e.getMessage().setBody("downstream-ok");
            });
    }
}

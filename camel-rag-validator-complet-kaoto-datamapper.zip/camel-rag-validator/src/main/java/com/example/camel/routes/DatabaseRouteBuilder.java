package com.example.camel.routes;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

@Component
public class DatabaseRouteBuilder extends RouteBuilder {
    @Override
    public void configure() {
        from("direct:dbInsert")
            .routeId("db-insert")
            .to("sql:INSERT INTO orders(id, amount, product_id, quantity, status) "
                + "VALUES (:#id, :#amount, :#productId, :#quantity, :#status)"
                + "?dataSource=#dataSource")
            .setBody(constant("inserted"));

        from("direct:dbSelect")
            .routeId("db-select")
            .to("sql:SELECT id, amount, product_id, quantity, status FROM orders WHERE id = :#id"
                + "?dataSource=#dataSource&outputType=SelectOne");

        from("direct:dbSelectAll")
            .routeId("db-select-all")
            .to("sql:SELECT id, amount, product_id, quantity, status FROM orders ORDER BY id"
                + "?dataSource=#dataSource");

        from("direct:transact")
            .routeId("db-transaction")
            .transacted()
            .to("sql:INSERT INTO orders(id, amount, product_id, quantity, status) "
                + "VALUES (:#id, :#amount, :#productId, :#quantity, 'CREATED')"
                + "?dataSource=#dataSource")
            .to("sql:UPDATE inventory SET qty = qty - :#quantity WHERE product_id = :#productId"
                + "?dataSource=#dataSource")
            .choice()
                .when(header("forceRollback").isEqualTo(true))
                    .throwException(new IllegalStateException("forced rollback"))
            .end()
            .setBody(constant("committed"));
    }
}

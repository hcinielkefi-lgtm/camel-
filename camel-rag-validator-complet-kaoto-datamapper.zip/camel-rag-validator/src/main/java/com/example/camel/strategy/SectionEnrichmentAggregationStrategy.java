package com.example.camel.strategy;

import java.util.LinkedHashMap;
import java.util.Map;
import org.apache.camel.AggregationStrategy;
import org.apache.camel.Exchange;

/**
 * Ajoute le résultat d'une ressource d'enrichissement sous une clé dédiée,
 * sans perdre le payload déjà enrichi par les étapes précédentes.
 */
public final class SectionEnrichmentAggregationStrategy implements AggregationStrategy {
    private final String section;

    public SectionEnrichmentAggregationStrategy(String section) {
        this.section = section;
    }

    @Override
    public Exchange aggregate(Exchange original, Exchange resource) {
        if (original == null) {
            return resource;
        }

        Map<String, Object> result = toMutableMap(original.getMessage().getBody());
        Object enrichment = resource == null ? null : resource.getMessage().getBody();
        result.put(section, enrichment);

        if (resource != null && resource.getException() != null) {
            result.put(section + "Error", resource.getException().getMessage());
        }

        original.getMessage().setBody(result);
        return original;
    }

    private Map<String, Object> toMutableMap(Object body) {
        if (body instanceof Map<?, ?> source) {
            Map<String, Object> copy = new LinkedHashMap<>();
            source.forEach((key, value) -> copy.put(String.valueOf(key), value));
            return copy;
        }

        Map<String, Object> wrapper = new LinkedHashMap<>();
        wrapper.put("payload", body);
        return wrapper;
    }
}

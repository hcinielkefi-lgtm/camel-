package com.example.camel.routes;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

@Component
@ConditionalOnProperty(
    name = {"demo.ibm-mq.enabled", "demo.kafka.enabled", "demo.messaging.bridge-enabled"},
    havingValue = "true"
)
public class OptionalMqKafkaBridgeRouteBuilder extends RouteBuilder {

    @Override
    public void configure() {
        // IBM MQ -> Kafka. Le message reçu sur la queue MQ d'entrée est publié
        // sur le topic Kafka de sortie via cette route dédiée.
        from("ibmmq:queue:{{demo.ibm-mq.input-queue}}.TO.KAFKA?bridgeErrorHandler=true")
            .routeId("bridge-ibm-mq-to-kafka")
            .removeHeaders("JMS*")
            .setHeader("bridgeSource", constant("ibm-mq"))
            .to("kafka:{{demo.kafka.output-topic}}");

        // Kafka -> IBM MQ. Un topic dédié évite de créer une boucle avec le
        // consumer Kafka principal.
        from("kafka:{{demo.kafka.input-topic}}.to-mq?groupId={{demo.kafka.group-id}}-mq-bridge")
            .routeId("bridge-kafka-to-ibm-mq")
            .removeHeaders("CamelKafka*")
            .setHeader("bridgeSource", constant("kafka"))
            .to("ibmmq:queue:{{demo.ibm-mq.output-queue}}?deliveryPersistent=true&jmsMessageType=Text");
    }
}

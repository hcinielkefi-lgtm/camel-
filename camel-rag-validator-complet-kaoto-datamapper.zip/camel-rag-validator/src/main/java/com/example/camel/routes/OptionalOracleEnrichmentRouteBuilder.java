package com.example.camel.routes;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

@Component
@ConditionalOnProperty(name = "demo.oracle.enabled", havingValue = "true")
public class OptionalOracleEnrichmentRouteBuilder extends RouteBuilder {
    private final int maxRedeliveries;
    private final long redeliveryDelayMs;

    public OptionalOracleEnrichmentRouteBuilder(
        @Value("${demo.oracle.redelivery.max:2}") int maxRedeliveries,
        @Value("${demo.oracle.redelivery.delay-ms:500}") long redeliveryDelayMs
    ) {
        this.maxRedeliveries = maxRedeliveries;
        this.redeliveryDelayMs = redeliveryDelayMs;
    }

    @Override
    public void configure() {
        onException(Exception.class)
            .maximumRedeliveries(maxRedeliveries)
            .redeliveryDelay(redeliveryDelayMs)
            .useExponentialBackOff()
            .backOffMultiplier(2.0)
            .handled(false);

        from("direct:oracleHealth")
            .routeId("oracle-health")
            .to("sql:SELECT 1 AS OK FROM DUAL?dataSource=#oracleDataSource&outputType=SelectOne");

        from("direct:oracleCustomer")
            .routeId("oracle-customer-by-id")
            .validate(header("customerId").isNotNull())
            .to("sql:classpath:sql/oracle/customer-by-id.sql"
                + "?dataSource=#oracleDataSource"
                + "&outputType=SelectOne"
                + "&template.queryTimeout={{demo.oracle.query-timeout-seconds}}");

        from("direct:oracleCustomerContracts")
            .routeId("oracle-customer-contracts")
            .validate(header("customerId").isNotNull())
            .process(exchange -> {
                if (exchange.getMessage().getHeader("limit") == null) {
                    int defaultLimit = Integer.parseInt(
                        exchange.getContext().resolvePropertyPlaceholders("{{demo.oracle.contract-limit}}")
                    );
                    exchange.getMessage().setHeader("limit", defaultLimit);
                }
            })
            .to("sql:classpath:sql/oracle/customer-contracts.sql"
                + "?dataSource=#oracleDataSource"
                + "&outputType=SelectList"
                + "&fetchSize={{demo.oracle.fetch-size}}"
                + "&template.queryTimeout={{demo.oracle.query-timeout-seconds}}");

        from("direct:oracleCustomerSummary")
            .routeId("oracle-customer-summary")
            .validate(header("customerId").isNotNull())
            .to("sql:classpath:sql/oracle/customer-summary.sql"
                + "?dataSource=#oracleDataSource"
                + "&outputType=SelectOne"
                + "&template.queryTimeout={{demo.oracle.query-timeout-seconds}}");

        from("direct:oracleUpdateCustomerStatus")
            .routeId("oracle-update-customer-status")
            .validate(header("customerId").isNotNull())
            .validate(header("customerStatus").isNotNull())
            .to("sql:UPDATE CRM_CUSTOMER SET CUSTOMER_STATUS = :#customerStatus, UPDATED_AT = SYSTIMESTAMP "
                + "WHERE CUSTOMER_ID = :#customerId"
                + "?dataSource=#oracleDataSource"
                + "&template.queryTimeout={{demo.oracle.query-timeout-seconds}}")
            .setBody(header("CamelSqlUpdateCount"));
    }
}

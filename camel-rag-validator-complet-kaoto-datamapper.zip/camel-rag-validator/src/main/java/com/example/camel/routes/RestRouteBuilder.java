package com.example.camel.routes;

import com.example.camel.model.Order;
import java.util.Map;
import org.apache.camel.Exchange;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.rest.RestBindingMode;
import org.springframework.stereotype.Component;

@Component
public class RestRouteBuilder extends RouteBuilder {
    @Override
    public void configure() {
        restConfiguration()
            .component("platform-http")
            .bindingMode(RestBindingMode.json)
            .dataFormatProperty("prettyPrint", "true")
            .apiContextPath("/api-doc")
            .apiProperty("api.title", "Camel RAG Validator API")
            .apiProperty("api.version", "2.0.0");

        rest("/api")
            .get("/health")
                .produces("application/json")
                .to("direct:restHealth")
            .post("/transform")
                .consumes("text/plain")
                .produces("text/plain")
                .to("direct:transform")
            .get("/orders")
                .produces("application/json")
                .to("direct:getOrders")
            .post("/orders")
                .consumes("application/json")
                .produces("application/json")
                .type(Order.class)
                .to("direct:createOrder")
            .get("/orders/{id}")
                .produces("application/json")
                .to("direct:getOrder");

        from("direct:restHealth")
            .routeId("rest-health")
            .setBody(constant(Map.of("status", "UP", "framework", "Apache Camel 4.22.0")))
            .setHeader(Exchange.CONTENT_TYPE, constant("application/json"));

        from("direct:getOrders")
            .routeId("rest-get-orders")
            .to("direct:dbSelectAll");

        from("direct:createOrder")
            .routeId("rest-create-order")
            .process(e -> {
                Order order = e.getMessage().getBody(Order.class);
                e.getMessage().setHeader("id", order.id());
                e.getMessage().setHeader("amount", order.amount());
                e.getMessage().setHeader("productId", order.productId());
                e.getMessage().setHeader("quantity", order.quantity() == null ? 1 : order.quantity());
                e.getMessage().setHeader("status", order.status() == null ? "CREATED" : order.status());
            })
            .to("direct:dbInsert")
            .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(201))
            .process(e -> e.getMessage().setBody(Map.of(
                "id", e.getMessage().getHeader("id", String.class),
                "status", e.getMessage().getHeader("status", String.class)
            )));

        from("direct:getOrder")
            .routeId("rest-get-order")
            .setHeader("id", header("id"))
            .to("direct:dbSelect")
            .choice()
                .when(body().isNull())
                    .setHeader(Exchange.HTTP_RESPONSE_CODE, constant(404))
                    .process(e -> e.getMessage().setBody(Map.of(
                        "error", "Order " + e.getMessage().getHeader("id", String.class) + " not found"
                    )))
            .end();
    }
}

package com.example.camel.service;

import org.apache.camel.Exchange;
import org.springframework.stereotype.Component;

@Component("dynamicRouterBean")
public class DynamicRouterBean {
    private static final String COUNTER = "dynamicRouterCounter";

    public String next(Exchange exchange) {
        Integer counter = exchange.getProperty(COUNTER, Integer.class);
        int next = counter == null ? 1 : counter + 1;
        exchange.setProperty(COUNTER, next);
        return switch (next) {
            case 1 -> "direct:stepA";
            case 2 -> "direct:stepB";
            case 3 -> "direct:stepC";
            default -> null;
        };
    }
}

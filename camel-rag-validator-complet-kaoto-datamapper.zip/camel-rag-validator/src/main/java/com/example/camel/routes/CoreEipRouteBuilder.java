package com.example.camel.routes;

import com.example.camel.strategy.StringAggregationStrategy;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

@Component
public class CoreEipRouteBuilder extends RouteBuilder {
    @Override
    public void configure() {
        from("direct:transform")
            .routeId("core-transform")
            .setHeader("source", constant("direct"))
            .setProperty("category", constant("demo"))
            .setVariable("internalNote", constant("variable-demo"))
            .process("myProcessor")
            .bean("myBean", "transform")
            .removeHeader("source");

        from("direct:choice")
            .routeId("core-choice-filter")
            .filter(body().isNotNull())
                .choice()
                    .when(body().contains("ERROR"))
                        .setHeader("classification", constant("error"))
                        .to("seda:errors")
                    .when(body().contains("WARN"))
                        .setHeader("classification", constant("warning"))
                        .to("seda:warnings")
                    .otherwise()
                        .setHeader("classification", constant("normal"))
                .endChoice()
            .end();

        from("seda:errors").routeId("core-errors-consumer").log("ERROR queue: ${body}");
        from("seda:warnings").routeId("core-warnings-consumer").log("WARN queue: ${body}");

        from("direct:split")
            .routeId("core-split")
            .split(body().tokenize(","))
                .streaming()
                .parallelProcessing()
                .to("seda:split-items")
            .end();

        from("seda:split-items")
            .routeId("core-split-items")
            .log("Split item index=${exchangeProperty.CamelSplitIndex}, body=${body}");

        from("direct:aggregate")
            .routeId("core-aggregate")
            .aggregate(header("batchId"), new StringAggregationStrategy())
                .completionSize(3)
                .completionTimeout(2000)
            .log("Aggregated: ${body}");

        from("direct:multicast")
            .routeId("core-multicast")
            .multicast().parallelProcessing()
                .to("direct:worker1", "direct:worker2", "direct:worker3")
            .end();

        from("direct:worker1").routeId("worker-1").setHeader("worker", constant("one")).log("worker1 ${body}");
        from("direct:worker2").routeId("worker-2").setHeader("worker", constant("two")).log("worker2 ${body}");
        from("direct:worker3").routeId("worker-3").setHeader("worker", constant("three")).log("worker3 ${body}");

        from("direct:recipientList")
            .routeId("core-recipient-list")
            .setHeader("recipients", constant("direct:worker1,direct:worker2"))
            .recipientList(header("recipients")).parallelProcessing();

        from("direct:routingSlip")
            .routeId("core-routing-slip")
            .setHeader("slip", constant("direct:stepA,direct:stepB,direct:stepC"))
            .routingSlip(header("slip"));

        from("direct:stepA").routeId("step-a").setBody(simple("${body}-A"));
        from("direct:stepB").routeId("step-b").setBody(simple("${body}-B"));
        from("direct:stepC").routeId("step-c").setBody(simple("${body}-C"));


        // Scatter-Gather: multicast parallèle + agrégation des réponses.
        from("direct:scatterGather")
            .routeId("core-scatter-gather")
            .multicast(new StringAggregationStrategy()).parallelProcessing().timeout(2000)
                .to("direct:gatherA", "direct:gatherB", "direct:gatherC")
            .end();

        from("direct:gatherA").routeId("gather-a").setBody(simple("A:${body}"));
        from("direct:gatherB").routeId("gather-b").setBody(simple("B:${body}"));
        from("direct:gatherC").routeId("gather-c").setBody(simple("C:${body}"));

        // Frontière de confiance: supprime les headers Camel internes avant un appel externe.
        from("direct:trustBoundary")
            .routeId("trust-boundary")
            .removeHeaders("Camel*")
            .setBody(simple("sanitized:${body}"));

        from("direct:wireTap")
            .routeId("core-wiretap")
            .wireTap("seda:audit")
            .setBody(simple("main:${body}"));

        from("seda:audit").routeId("audit-consumer").log("AUDIT copy: ${body}");
    }
}

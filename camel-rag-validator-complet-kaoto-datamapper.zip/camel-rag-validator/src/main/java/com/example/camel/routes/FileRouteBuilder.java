package com.example.camel.routes;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

@Component
public class FileRouteBuilder extends RouteBuilder {
    @Override
    public void configure() {
        from("file:data/input?readLock=changed&move=.done/${file:name}&moveFailed=.error/${file:name}")
            .routeId("file-ingestion")
            .filter(body().isNotNull())
                .choice()
                    .when(body().contains("ERROR"))
                        .to("file:data/rejected")
                    .otherwise()
                        .process("myProcessor")
                        .bean("myBean", "transform")
                        .to("file:data/output")
                .end()
            .end();
    }
}

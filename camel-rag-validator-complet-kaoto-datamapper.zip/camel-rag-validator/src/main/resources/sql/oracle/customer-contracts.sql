SELECT *
FROM (
    SELECT
        ct.CONTRACT_ID,
        ct.CUSTOMER_ID,
        ct.PRODUCT_CODE,
        ct.CONTRACT_STATUS,
        ct.START_DATE,
        ct.END_DATE,
        ct.AMOUNT,
        ct.CURRENCY_CODE
    FROM CRM_CONTRACT ct
    WHERE ct.CUSTOMER_ID = :#customerId
    ORDER BY ct.START_DATE DESC
)
WHERE ROWNUM <= :#limit

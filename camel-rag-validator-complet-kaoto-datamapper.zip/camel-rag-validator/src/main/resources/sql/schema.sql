CREATE TABLE IF NOT EXISTS orders (
    id VARCHAR(255) PRIMARY KEY,
    amount DECIMAL(12,2) NOT NULL,
    product_id VARCHAR(255) NOT NULL,
    quantity INT NOT NULL,
    status VARCHAR(50) NOT NULL
);

CREATE TABLE IF NOT EXISTS inventory (
    product_id VARCHAR(255) PRIMARY KEY,
    qty INT NOT NULL
);

MERGE INTO inventory KEY(product_id) VALUES ('P001', 100);
MERGE INTO inventory KEY(product_id) VALUES ('P002', 50);

#!/usr/bin/env bash
export NR_DATASET_VERSION=${NR_DATASET_VERSION:-2.1.0}
set -euo pipefail
cd "$(dirname "$0")/.."
exec mvn spring-boot:run

# Enrichissement Oracle + API REST

> **Dataset non-régression V2.1.0** — cette version contient volontairement des changements de contrat, de configuration, de routage, de données et de ressources afin de tester un moteur de comparaison V1/V2.


Ce module est opt-in. Le projet continue à fonctionner avec H2 tant que le profil `enrichment` n'est pas activé. H2 reste également la datasource `@Primary` lorsque Oracle est activé; les endpoints SQL nomment explicitement la datasource à utiliser.

## Activation

```bash
export ORACLE_URL='jdbc:oracle:thin:@//oracle.example.internal:1521/APPDB'
export ORACLE_USERNAME='camel_app'
export ORACLE_PASSWORD='change-me'

export ENRICHMENT_API_BASE_URL='https://enrichment.example.internal/api'
export ENRICHMENT_API_AUTH_TYPE='bearer'
export ENRICHMENT_API_TOKEN='change-me'

mvn spring-boot:run -Dspring-boot.run.arguments="--spring.profiles.active=enrichment"
```

## Routes Oracle

| Endpoint Camel | Usage |
|---|---|
| `direct:oracleHealth` | `SELECT 1 FROM DUAL` |
| `direct:oracleCustomer` | Client unique par `customerId` |
| `direct:oracleCustomerSummary` | Agrégats client/contrats |
| `direct:oracleCustomerContracts` | Derniers contrats, limite configurable |
| `direct:oracleUpdateCustomerStatus` | UPDATE paramétré du statut |

Les requêtes SELECT sont externalisées sous `src/main/resources/sql/oracle/` et utilisent les paramètres nommés Camel `:#customerId` / `:#limit`. Elles référencent explicitement `#oracleDataSource`, donc elles ne remplacent pas H2.

### Exemple Java

```java
Map<String, Object> customer = producerTemplate.requestBodyAndHeader(
    "direct:oracleCustomer", null, "customerId", "C00042", Map.class);
```

## Routes REST sortantes

L'API cible attend, par convention de démonstration :

```text
GET  {baseUrl}/customers/{customerId}
POST {baseUrl}/risk/evaluate
```

Le POST reçoit par exemple :

```json
{
  "customerId": "C00042",
  "countryCode": "TN",
  "requestedBy": "camel-rag-validator"
}
```

Authentification supportée dans l'exemple : `none`, Bearer token et API key. Les headers `CamelHttp*` sont supprimés avant l'appel afin qu'un message entrant ne puisse pas détourner l'URI HTTP.

Les codes HTTP sont normalisés :

- 2xx : JSON converti en `Map` ;
- 404 : `{ "found": false, "httpStatus": 404 }` ;
- autres 4xx : réponse structurée `remote-api-error` ;
- 429 et 5xx : exception pour permettre retry / circuit breaker au niveau supérieur.

## Enrichissement composite

`direct:enrichCustomerExternal` enchaîne :

1. Oracle client ;
2. Oracle synthèse ;
3. Oracle contrats ;
4. REST profil distant ;
5. REST scoring risque.

Exemple d'entrée :

```java
var response = producerTemplate.requestBodyAndHeaders(
    "direct:enrichCustomerExternal",
    Map.of("eventType", "ORDER_CREATED", "orderId", "O-123"),
    Map.of("customerId", "C00042", "countryCode", "TN")
);
```

La sortie conserve le payload original et ajoute des sections indépendantes :

```json
{
  "customerId": "C00042",
  "payload": {"eventType":"ORDER_CREATED","orderId":"O-123"},
  "oracleCustomer": {},
  "oracleSummary": {},
  "oracleContracts": [],
  "remoteCustomer": {},
  "risk": {},
  "enriched": true
}
```

## Sécurité

- ne jamais concaténer `customerId` dans le SQL : utiliser `:#customerId` ;
- stocker les secrets dans un gestionnaire de secrets / variables d'environnement ;
- utiliser TLS côté Oracle et HTTPS côté REST en production ;
- ne pas journaliser le header `Authorization` ;
- limiter les timeouts et la taille des résultats ;
- supprimer les headers internes Camel avant toute frontière de confiance.

## Adapter les tables

Les exemples supposent `CRM_CUSTOMER` et `CRM_CONTRACT`. Remplacer les fichiers `.sql` par les noms de tables, vues ou synonymes de votre SI sans modifier les routes Java.


## JSON

Le projet utilise `camel-jackson3-starter`, recommandé pour Camel 4.22 / Spring Boot 4, tout en conservant le DSL générique `JsonLibrary.Jackson`.

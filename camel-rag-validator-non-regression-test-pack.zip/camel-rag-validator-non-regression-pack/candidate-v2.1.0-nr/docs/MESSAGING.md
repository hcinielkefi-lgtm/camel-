# IBM MQ (MQSeries) et Kafka

> **Dataset non-régression V2.1.0** — cette version contient volontairement des changements de contrat, de configuration, de routage, de données et de ressources afin de tester un moteur de comparaison V1/V2.


## 1. IBM MQ / MQSeries

Le projet utilise `camel-jms-starter` et le client Jakarta Messaging IBM MQ.
Le composant Camel est enregistré sous le nom `ibmmq`.

Variables principales :

```bash
export IBM_MQ_HOST=localhost
export IBM_MQ_PORT=1414
export IBM_MQ_QUEUE_MANAGER=QM1
export IBM_MQ_CHANNEL=DEV.APP.SVRCONN
export IBM_MQ_USERNAME=app
export IBM_MQ_PASSWORD='change-me'
export IBM_MQ_INPUT_QUEUE=DEV.QUEUE.1
export IBM_MQ_OUTPUT_QUEUE=DEV.QUEUE.2
```

TLS IBM MQ :

```bash
export IBM_MQ_SSL_CIPHER_SUITE='TLS_AES_256_GCM_SHA384'
```

Routes :

- `ibmmq:queue:${IBM_MQ_INPUT_QUEUE}` -> `direct:mqInbound`
- `direct:mqSend` -> `${IBM_MQ_OUTPUT_QUEUE}`
- `direct:mqRequestReply` -> requête/réponse JMS
- `direct:mqDlq` -> `${IBM_MQ_DLQ}`

## 2. Kafka

Variables principales :

```bash
export KAFKA_BROKERS=localhost:9092
export KAFKA_INPUT_TOPIC=camel-input
export KAFKA_OUTPUT_TOPIC=camel-output
export KAFKA_DLQ_TOPIC=camel-dlq
export KAFKA_GROUP_ID=camel-rag-validator
```

Routes :

- `${KAFKA_INPUT_TOPIC}` -> `direct:kafkaInbound`
- `direct:kafkaSend` -> `${KAFKA_OUTPUT_TOPIC}`
- `direct:kafkaSendDynamic` -> topic fourni dans le header `kafkaTargetTopic`
- échec après retries -> `${KAFKA_DLQ_TOPIC}`

### Kafka SASL/SSL

Activer le profil `kafka-secure` et fournir :

```bash
export KAFKA_SECURITY_PROTOCOL=SASL_SSL
export KAFKA_SASL_AUTH_TYPE=PLAIN
export KAFKA_USERNAME='user'
export KAFKA_PASSWORD='secret'
```

Pour SCRAM, utiliser `SCRAM_SHA_256` ou `SCRAM_SHA_512` si le cluster est configuré ainsi.

## 3. Activation

IBM MQ + Kafka :

```bash
mvn spring-boot:run -Dspring-boot.run.arguments="--spring.profiles.active=messaging"
```

Kafka sécurisé :

```bash
mvn spring-boot:run -Dspring-boot.run.arguments="--spring.profiles.active=messaging,kafka-secure"
```

Sans profil `messaging`, aucun consumer MQ/Kafka n'est lancé.

## 4. Pont IBM MQ <-> Kafka

Le pont est désactivé par défaut. Pour l'activer :

```bash
export MESSAGING_BRIDGE_ENABLED=true
```

Sens MQ -> Kafka :

`<IBM_MQ_INPUT_QUEUE>.TO.KAFKA` -> `<KAFKA_OUTPUT_TOPIC>`

Sens Kafka -> MQ :

`<KAFKA_INPUT_TOPIC>.to-mq` -> `<IBM_MQ_OUTPUT_QUEUE>`

Des destinations dédiées sont utilisées pour réduire le risque de boucle de routage.

## 5. Production

Ne stocker aucun mot de passe dans Git. Utiliser un secret manager, Kubernetes Secret,
Vault ou les mécanismes de secrets de la plateforme. En production, activer TLS sur IBM MQ
et Kafka, limiter les ACL aux queues/topics nécessaires et superviser les DLQ.

## 6. Endpoints HTTP de test

Quand l'application tourne :

```bash
curl http://localhost:8080/api/messaging/status

curl -X POST http://localhost:8080/api/messaging/mq \
  -H 'Content-Type: text/plain' \
  --data 'hello IBM MQ'

curl -X POST http://localhost:8080/api/messaging/kafka \
  -H 'Content-Type: text/plain' \
  --data 'hello Kafka'
```

Le endpoint MQ request/reply est `POST /api/messaging/mq/request-reply`.

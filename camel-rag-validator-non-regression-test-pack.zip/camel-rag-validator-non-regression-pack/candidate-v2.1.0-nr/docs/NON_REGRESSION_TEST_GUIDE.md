# Guide de test de non-régression — V2.1.0

Cette candidate est conçue pour être comparée à la version de référence `camel-rag-validator` V2.0.0.

## Oracle de comparaison

Utiliser en priorité :

- `non-regression-manifest.json` pour les changements de fichiers attendus ;
- `expected-change-matrix.csv` pour les changements sémantiques majeurs ;
- `expected-v1-to-v2.patch` pour le diff textuel brut ;
- `baseline-checksums-v1.sha256` et `checksums-v2.sha256` pour les contrôles d'intégrité.

## Scénarios à tester

1. Détection de fichiers modifiés.
2. Détection de nouveaux fichiers.
3. Détection de suppression.
4. Détection de renommage par contenu identique.
5. Détection de changement de contrat REST/OpenAPI.
6. Détection de changement de modèle Java et de schéma SQL.
7. Détection de changement de paramètres Camel EIP.
8. Détection de changement de configuration MQ/Kafka.
9. Détection de changement de requêtes Oracle.
10. Détection de règles XPath et XSLT modifiées.
11. Détection d'évolution XSD et DataMapper Kaoto.
12. Détection de tests ajoutés et de fixtures modifiées.

## Changements volontairement cassants

Certains changements doivent être remontés comme incompatibles : Java 17 → 21, port 8080 → 8081, contrat `Order`, réponse POST `/api/orders` 201 → 202 et remplacement de `order.xsd`.

## Résultat attendu

Le comparateur ne doit pas considérer cette candidate comme identique à la baseline. Le manifest fournit le nombre exact de changements de fichiers hors métadonnées de comparaison.

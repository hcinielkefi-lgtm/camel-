# Non Regression Change Set — V2.1.0

Cette version est volontairement différente de la version de référence. Elle sert de jeu de données pour tester un outil de non-régression.

## Types de changements simulés

- **Contrat** : `Order` ajoute `channel`, création REST passe de 201 à 202, OpenAPI ajoute `/summary`.
- **Persistance** : colonne `channel`, `updated_at`, table `integration_audit`, stock initial modifié.
- **EIP** : nouvelle branche CRITICAL, quatrième worker, agrégation 3→4, recipient list élargie, routing slip réordonné.
- **Résilience** : retries/délais/circuit breaker modifiés.
- **Messaging** : topics Kafka V2, concurrence accrue, file MQ prioritaire, nouveaux headers de version.
- **Oracle** : projections SQL enrichies, contrats annulés filtrés, synthèse avec `VALUE_BAND`.
- **REST enrichment** : headers de corrélation/version, payload risk V2, gestion HTTP 409.
- **XPath** : seuil 1000→1250, fraude ajoutée, format catégories modifié.
- **Kaoto/XSLT** : seuil priorité modifié, nouveaux champs `MappingVersion` et `HighValueLineCount`.
- **DSL XML/YAML/Kamelet** : périodes/messages/support-level modifiés.
- **Ajouts** : `NonRegressionScenarioRouteBuilder`, test associé, manifest, checksum, XSD V2.
- **Renommages** : `VALIDATION.md`→`QUALITY_GATES.md`, `advanced-order.xml`→`advanced-order-v2.xml`.
- **Suppression** : `order.xsd` remplacé par `order-v2.xsd`.

Voir `non-regression-manifest.json` pour une liste machine-friendly calculée à partir des deux arbres.

# Kaoto DataMapper + XSLT 3.0 complexe

> **Dataset non-régression V2.1.0** — cette version contient volontairement des changements de contrat, de configuration, de routage, de données et de ressources afin de tester un moteur de comparaison V1/V2.


## But

Ce scénario montre comment représenter une transformation XML métier avancée avec le DataMapper de Kaoto puis l'exécuter dans Apache Camel avec `xslt-saxon`.

Le mapping transforme un `order` multi-namespace en `FulfillmentOrder`. Il couvre :

- plusieurs schémas XSD source avec `xs:import` ;
- un schéma XSD cible ;
- paramètres provenant des headers/variables Camel ;
- namespaces XML source et cible ;
- XPath complexes ;
- variables XSLT ;
- `xsl:choose / xsl:when / xsl:otherwise` ;
- `xsl:for-each` ;
- `xsl:sort` ;
- fonctions XPath/XSLT 3.0 (`upper-case`, `exists`, `avg`, `distinct-values`, `sort`, `string-join`) ;
- calculs et conversion monétaire ;
- validation XSD du résultat.

## Fichiers

```text
src/main/resources/kaoto/datamapper/
├── complex-order-datamapper.camel.yaml
├── order-to-fulfillment-kaoto-datamapper.xsl
├── schemas/
│   ├── source/
│   │   ├── order-source.xsd
│   │   ├── customer.xsd
│   │   └── product.xsd
│   └── target/
│       └── fulfillment-target.xsd
└── samples/
    ├── order-input.xml
    └── fulfillment-expected.xml
```

La version Java DSL exécutable est `KaotoDataMapperRouteBuilder` et expose `direct:kaotoDataMapperXslt`.

## Modélisation dans Kaoto

1. Ouvrir `complex-order-datamapper.camel.yaml` dans Kaoto.
2. Sélectionner le step `kaoto-datamapper-complex-order`.
3. Ouvrir le DataMapper.
4. Attacher au document source `schemas/source/order-source.xsd`, puis ses dépendances `customer.xsd` et `product.xsd` si Kaoto les demande.
5. Choisir `order` comme racine source.
6. Attacher `schemas/target/fulfillment-target.xsd` comme schéma cible et choisir `FulfillmentOrder`.
7. Ajouter les paramètres source `sourceSystem`, `correlationId`, `exchangeRate` et `processingDate`.
8. Créer les mappings simples par drag-and-drop, puis les mappings complexes avec l'éditeur XPath.

Kaoto 2.10+ sait gérer plusieurs fichiers de schéma et les dépendances `xs:import`/`xs:include`. Le DataMapper génère du XSLT 3.0 exécuté avec le composant Camel XSLT Saxon.

## Mappings intéressants

### Priorité avec `choose/when/otherwise`

Pseudo-règle :

```text
HIGH + VIP + total actif >= 1000  -> P1
flag manuel ou ligne hazardous    -> P2-REVIEW
total actif >= 500                -> P2
sinon                             -> P3
```

### Collection de lignes

Le mapping cible `Lines/Line` parcourt seulement :

```xpath
/o:order/o:lines/o:line[@active = 'true']
```

Chaque ligne est triée par `lineTotal` décroissant avant génération.

### Paramètres Camel

Le XSLT déclare :

```xml
<xsl:param name="sourceSystem"/>
<xsl:param name="correlationId"/>
<xsl:param name="exchangeRate"/>
<xsl:param name="processingDate"/>
```

`camel-xslt-saxon` expose les headers et variables Camel comme paramètres XSLT. La route Java prépare donc ces valeurs avant le `to("xslt-saxon:...")`.

### Fonctions XPath 3.0

Le résumé construit la liste des catégories uniques avec :

```xpath
string-join(sort(distinct-values($activeLines/p:product/@category)), ',')
```

et calcule la moyenne avec :

```xpath
avg($activeLines/@lineTotal)
```

## Important : édition visuelle et XSLT manuel

Le fichier XSLT fourni est volontairement écrit dans une forme proche de celle générée par Kaoto DataMapper afin de servir d'exemple et de corpus RAG. Cependant, il ne faut pas supposer que Kaoto peut reconstruire visuellement n'importe quel XSLT écrit à la main. Le support d'import arbitraire d'un XSLT existant est encore suivi côté Kaoto.

Pour une démonstration DataMapper fiable, la méthode recommandée est donc : attacher les schémas dans Kaoto, créer les mappings dans l'éditeur visuel, puis laisser Kaoto générer/maintenir le fichier XSLT.

## Exécution Spring Boot

```java
producerTemplate.requestBodyAndHeaders(
    "direct:kaotoDataMapperXslt",
    xml,
    Map.of(
        "sourceSystem", "KAOTO-DEMO",
        "correlationId", "CORR-1001",
        "exchangeRate", "1.10"
    )
);
```

Le résultat est ensuite validé par :

```text
validator:classpath:kaoto/datamapper/schemas/target/fulfillment-target.xsd
```

## Cas supplémentaires à expérimenter dans Kaoto

- remplacer `Market` par un `if` XPath compact ;
- ajouter un `choose` sur les flags métier ;
- mapper une deuxième source stockée dans une Camel Variable ;
- ajouter un schéma source importé supplémentaire ;
- utiliser `xs:choice` dans le schéma cible ;
- tester un type dérivé via `xs:extension` et Field Override ;
- produire une cible JSON via DataMapper ;
- comparer le XSLT généré par Kaoto avec la version de référence de ce projet.

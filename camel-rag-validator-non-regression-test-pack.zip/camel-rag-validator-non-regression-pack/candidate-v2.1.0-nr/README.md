# camel-rag-validator 2.2

> **Dataset non-régression V2.1.0** — cette version contient volontairement des changements de contrat, de configuration, de routage, de données et de ressources afin de tester un moteur de comparaison V1/V2.


Catalogue exécutable et extensible pour **Apache Camel 4.22.0 LTS**, **Spring Boot 4.1.0** et **Java 17**.

L'objectif n'est pas d'embarquer simultanément les centaines de composants Camel (ce qui rendrait le projet lourd et exigerait de nombreuses infrastructures), mais de fournir un **socle de validation/RAG très large** couvrant les principales familles d'EIP, DSL, transports, erreurs, transactions, observabilité et intégrations, avec les connecteurs externes désactivés par défaut.

## Démarrage

Prérequis : JDK 17+ et Maven 3.9+.

```bash
mvn clean verify
mvn spring-boot:run
```

Vérifications HTTP :

```bash
curl http://localhost:8080/api/health
curl http://localhost:8080/api/orders
curl -X POST http://localhost:8080/api/transform \
  -H 'Content-Type: text/plain' \
  --data 'bonjour camel'
```

Créer puis lire une commande :

```bash
curl -X POST http://localhost:8080/api/orders \
  -H 'Content-Type: application/json' \
  -d '{"id":"O-1","amount":19.90,"productId":"P001","quantity":2,"status":"CREATED"}'

curl http://localhost:8080/api/orders/O-1
```

## Couverture incluse

### Routage / EIP

- Direct, SEDA, File, Timer
- Choice, Filter, Stop
- Split streaming + parallèle
- Aggregate avec `AggregationStrategy`
- Multicast parallèle
- Scatter-Gather (Multicast + agrégation)
- Recipient List
- Routing Slip
- Dynamic Router
- Dynamic To (`toD`)
- Wire Tap
- Enrich / Poll Enrich
- Claim Check
- Sort
- Resequencer batch
- Validate
- Throttle, Delay, Loop, Threads, Sample
- Load Balancer : Round Robin, Weighted, Failover
- Idempotent Consumer
- Step EIP
- OnCompletion
- Route Configuration réutilisable
- Control Bus (lecture d'état d'une route)
- Rollback / Throw Exception
- Route Template
- Kamelet Java + Kamelet chargé depuis `classpath:kamelets`

### Transformation / données

- Processor Java
- Bean EIP
- Simple language
- Headers, Exchange Properties et Variables
- Type Converter
- JSON Jackson marshal/unmarshal
- JSONPath
- XSLT Saxon
- Kaoto DataMapper + XSLT 3.0 complexe
- XSD multi-fichiers (`xs:import`) pour DataMapper
- Validation XSD
- SQL + H2

### Fiabilité / transactions

- Dead Letter Channel
- Redelivery + backoff exponentiel
- `onException`
- `doTry` / `doCatch` / `doFinally`
- Circuit Breaker Resilience4j + fallback
- Transaction JDBC locale avec rollback vérifié par test
- Saga avec compensation/completion via `InMemorySagaService`

> `InMemorySagaService` est adapté à la démonstration et aux tests, pas à une saga distribuée durable de production.

### API / contrats

- REST DSL avec `platform-http`
- Binding JSON
- OpenAPI exposé par Camel/Springdoc
- Contrat `openapi.yaml`
- Client `rest-openapi` optionnel basé sur `operationId`
- Client HTTP Camel disponible

### DSL

- Java DSL
- XML DSL
- YAML DSL Camel 4 (`camelCase` : `setBody`, `setHeader`, `routeTemplate`, etc.)

### Exploitation / sécurité

- Actuator
- Micrometer + Prometheus registry
- JMX / Message History
- Control Bus
- Exemple de frontière de confiance avec suppression des en-têtes internes `Camel*`
- Secrets des connecteurs externes externalisés dans les propriétés / variables d'environnement

### IA / RAG

Le starter Camel OpenAI est inclus mais la route est **désactivée par défaut** :

- `direct:aiChat` → `openai:chat-completion`
- `direct:aiEmbeddings` → `openai:embeddings`

Activation :

```bash
export OPENAI_API_KEY='...'
export OPENAI_MODEL='...'
export OPENAI_EMBEDDING_MODEL='...'
mvn spring-boot:run -Dspring-boot.run.arguments="--demo.openai.enabled=true"
```

Aucun secret n'est stocké dans le dépôt.

## Connecteurs externes optionnels

### IBM MQ (MQSeries) + Kafka

Les deux connecteurs sont fournis en mode opt-in. La configuration complète, y compris TLS/SASL et le pont MQ ↔ Kafka, est décrite dans [`docs/MESSAGING.md`](docs/MESSAGING.md).

Démarrage local avec les deux connecteurs :

```bash
export IBM_MQ_HOST=localhost
export IBM_MQ_PORT=1414
export IBM_MQ_QUEUE_MANAGER=QM1
export IBM_MQ_CHANNEL=DEV.APP.SVRCONN
export IBM_MQ_USERNAME=app
export IBM_MQ_PASSWORD='change-me'
export KAFKA_BROKERS=localhost:9092

mvn spring-boot:run \
  -Dspring-boot.run.arguments="--spring.profiles.active=messaging"
```

Routes d'envoi directes : `direct:mqSend`, `direct:mqRequestReply`, `direct:mqDlq`, `direct:kafkaSend`, `direct:kafkaSendDynamic`.

### SFTP

```bash
mvn spring-boot:run \
  -Dspring-boot.run.arguments="--demo.sftp.enabled=true --demo.sftp.host=localhost --demo.sftp.username=camel --demo.sftp.password=change-me"
```

### REST OpenAPI contract-first

Le client est désactivé par défaut pour éviter une dépendance réseau au démarrage :

```bash
mvn spring-boot:run \
  -Dspring-boot.run.arguments="--demo.openapi-client.enabled=true --demo.openapi-client.host=http://localhost:8080"
```

Puis appeler `direct:openapiGetOrders` via un `ProducerTemplate` ou un test.

## Routes `direct:*` utiles

### Core

`direct:transform`, `direct:choice`, `direct:split`, `direct:aggregate`, `direct:multicast`, `direct:scatterGather`, `direct:recipientList`, `direct:routingSlip`, `direct:dynamicRouter`, `direct:toD`, `direct:wireTap`, `direct:claimCheck`, `direct:sort`, `direct:resequence`, `direct:validate`.

### Flow / résilience

`direct:throttle`, `direct:delay`, `direct:loop`, `direct:stop`, `direct:threads`, `direct:sample`, `direct:idempotent`, `direct:circuitBreaker`, `direct:localTryCatch`, `direct:triggerBusinessError`, `direct:rollbackDemo`.

### Management / configuration

`direct:stepDemo`, `direct:routeStatus`, `direct:routeConfigurationDemo`, `direct:onCompletion`.

### Transformation / stockage

`direct:jsonMarshal`, `direct:jsonUnmarshal`, `direct:jsonPath`, `direct:xslt`, `direct:kaotoDataMapperXslt`, `direct:xmlValidate`, `direct:dbInsert`, `direct:dbSelect`, `direct:dbSelectAll`, `direct:transact`.

### Orchestration / DSL

`direct:sagaOrder`, `direct:xmlDemo`, `direct:yamlDemo`, `direct:kameletDemo`, `direct:kameletFileDemo`.

## Kaoto DataMapper + XSLT 3.0 complexe

Le projet contient un scénario XML → XML dédié à Kaoto DataMapper : schémas source multi-fichiers, schéma cible, paramètres Camel, `choose/when/otherwise`, `for-each`, tri, calculs et fonctions XPath/XSLT 3.0.

- route Java : `direct:kaotoDataMapperXslt`
- exemple Kaoto YAML : `src/main/resources/kaoto/datamapper/complex-order-datamapper.camel.yaml`
- XSLT : `src/main/resources/kaoto/datamapper/order-to-fulfillment-kaoto-datamapper.xsl`
- guide : [`docs/KAOTO_DATAMAPPER_XSLT.md`](docs/KAOTO_DATAMAPPER_XSLT.md)

Le guide précise aussi la limite actuelle de l'import d'un XSLT manuel dans l'éditeur visuel Kaoto.

## Tests fournis

- chargement du contexte et des routes
- Java/XML/YAML DSL
- transformation Processor + Bean
- Routing Slip
- Dynamic Router / `toD`
- Claim Check / Sort
- Scatter-Gather
- nettoyage des en-têtes Camel à la frontière de confiance
- Kamelet classpath
- transaction commit et rollback

Commande :

```bash
mvn clean verify
```

## Ce que signifie « tous les cas Camel 4 »

Camel possède un très grand catalogue de composants. Ajouter AWS, Azure, Google Cloud, SAP, Salesforce, JMS, Artemis, RabbitMQ, AMQP, MQTT, MongoDB, Cassandra, Redis, OpenSearch, CXF, gRPC, mail, Kubernetes, etc. dans le runtime de base nécessiterait des services externes, des credentials et des dépendances importantes.

Le projet adopte donc trois niveaux :

1. **Exécutable localement** : EIP et composants sans infrastructure externe.
2. **Optionnel mais codé** : Kafka, SFTP, OpenAI, REST OpenAPI.
3. **Catalogue d'extension** : familles restantes dans `docs/CATALOGUE.md`.

Cette organisation est mieux adaptée à un corpus RAG : chaque cas reste identifiable et peut être enrichi séparément sans rendre le contexte Spring impossible à démarrer.

## Arborescence

```text
src/main/java/com/example/camel/
├── config/       # transaction + route configuration
├── model/        # records / DTO
├── processor/    # Processor
├── routes/       # routes par famille fonctionnelle
├── service/      # beans de routage/transformation
└── strategy/     # AggregationStrategy

src/main/resources/
├── camel/        # XML + YAML DSL
├── kamelets/     # Kamelets classpath
├── sql/          # schéma H2
├── openapi.yaml
├── order-v2.xsd
└── transform.xsl
```


## Oracle + API REST pour enrichissement

Un profil `enrichment` ajoute une datasource Oracle indépendante de H2, des requêtes SQL paramétrées externalisées, des appels HTTP GET/POST et un flux composite `direct:enrichCustomerExternal`.

```bash
export ORACLE_URL='jdbc:oracle:thin:@//localhost:1521/FREEPDB1'
export ORACLE_USERNAME=camel
export ORACLE_PASSWORD='change-me'
export ENRICHMENT_API_BASE_URL='https://api.example.com'
export ENRICHMENT_API_AUTH_TYPE=bearer
export ENRICHMENT_API_TOKEN='change-me'
mvn spring-boot:run -Dspring-boot.run.arguments="--spring.profiles.active=enrichment"
```

Voir `docs/ORACLE_REST_ENRICHMENT.md`.

## Livrable organisé

Pour naviguer rapidement dans le projet :

- `docs/INDEX.md` : point d'entrée de la documentation
- `docs/ARCHITECTURE.md` : architecture logique et organisation des packages
- `.env.example` : toutes les variables d'environnement dans un seul fichier
- `scripts/run-local.sh` : exécution sans infrastructure externe
- `scripts/run-messaging.sh` : IBM MQ + Kafka
- `scripts/run-enrichment.sh` : Oracle + REST
- `scripts/run-all.sh` : IBM MQ + Kafka + Oracle + REST
- `scripts/verify.sh` : `mvn clean verify`

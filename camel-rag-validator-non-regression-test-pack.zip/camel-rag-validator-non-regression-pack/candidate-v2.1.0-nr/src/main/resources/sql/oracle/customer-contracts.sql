SELECT *
FROM (
    SELECT
        ct.CONTRACT_ID,
        ct.CUSTOMER_ID,
        ct.PRODUCT_CODE,
        ct.CONTRACT_STATUS,
        ct.START_DATE,
        ct.END_DATE,
        ct.AMOUNT,
        ct.CURRENCY_CODE,
        ROW_NUMBER() OVER (ORDER BY ct.START_DATE DESC, ct.CONTRACT_ID) AS RN
    FROM CRM_CONTRACT ct
    WHERE ct.CUSTOMER_ID = :#customerId
      AND ct.CONTRACT_STATUS <> 'CANCELLED'
)
WHERE RN <= :#limit
ORDER BY RN

package com.example.camel.routes;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

@Component
public class FlowControlRouteBuilder extends RouteBuilder {
    @Override
    public void configure() {
        from("direct:throttle")
            .routeId("flow-throttle")
            .throttle(8).timePeriodMillis(1000)
            .log("Throttled: ${body}");

        from("direct:delay")
            .routeId("flow-delay")
            .delay(150)
            .setBody(simple("delayed:${body}"));

        from("direct:loop")
            .routeId("flow-loop")
            .setHeader("iterations", constant(4))
            .loop(header("iterations"))
                .log("Loop ${exchangeProperty.CamelLoopIndex}: ${body}")
            .end();

        from("direct:stop")
            .routeId("flow-stop")
            .choice()
                .when(header("stop").isEqualTo(true))
                    .stop()
                .otherwise()
                    .setBody(simple("continued:${body}"))
            .end();

        from("direct:threads")
            .routeId("flow-threads")
            .threads(3, 6)
            .log("Thread=${threadName}, body=${body}");

        from("direct:sample")
            .routeId("flow-sample")
            .sample(1)
            .log("Sampled ${body}");
    }
}

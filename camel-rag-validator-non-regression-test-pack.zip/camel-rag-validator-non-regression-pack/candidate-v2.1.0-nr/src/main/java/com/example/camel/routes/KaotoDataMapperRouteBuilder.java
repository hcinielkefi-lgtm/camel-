package com.example.camel.routes;

import java.time.LocalDate;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

/**
 * Version Java DSL exécutable du scénario Kaoto DataMapper.
 *
 * La route YAML équivalente se trouve sous
 * src/main/resources/kaoto/datamapper/complex-order-datamapper.camel.yaml.
 */
@Component
public class KaotoDataMapperRouteBuilder extends RouteBuilder {

    @Override
    public void configure() {
        from("direct:kaotoDataMapperXslt")
            .routeId("kaoto-datamapper-xslt-complex")
            .streamCache(true)
            .process(exchange -> {
                var message = exchange.getMessage();
                if (message.getHeader("sourceSystem") == null) {
                    message.setHeader("sourceSystem", "CAMEL-NR-V2");
                }
                if (message.getHeader("correlationId") == null) {
                    message.setHeader("correlationId", exchange.getExchangeId());
                }
                if (message.getHeader("exchangeRate") == null) {
                    message.setHeader("exchangeRate", "1.05");
                }
                if (message.getHeader("processingDate") == null) {
                    message.setHeader("processingDate", LocalDate.now().toString());
                }
            })
            .to("xslt-saxon:classpath:kaoto/datamapper/order-to-fulfillment-kaoto-datamapper.xsl")
            .to("validator:classpath:kaoto/datamapper/schemas/target/fulfillment-target.xsd")
            .setHeader("kaotoDataMapperValidated", constant(true))
            .setHeader("mappingVersion", constant("2.1.0"));
    }
}

package com.example.camel.routes;

import com.example.camel.model.Order;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.dataformat.JsonLibrary;
import org.springframework.stereotype.Component;

@Component
public class DataFormatRouteBuilder extends RouteBuilder {
    @Override
    public void configure() {
        from("direct:jsonMarshal")
            .routeId("json-marshal")
            .marshal().json(JsonLibrary.Jackson);

        from("direct:jsonUnmarshal")
            .routeId("json-unmarshal")
            .unmarshal().json(JsonLibrary.Jackson, Order.class);

        from("direct:jsonPath")
            .routeId("jsonpath-demo")
            .setBody().jsonpath("$.customer.name");

        from("direct:xslt")
            .routeId("xslt-demo")
            .to("xslt-saxon:classpath:transform.xsl");

        from("direct:xmlValidate")
            .routeId("xml-validation")
            .to("validator:classpath:order-v2.xsd")
            .setHeader("valid", constant(true));
    }
}

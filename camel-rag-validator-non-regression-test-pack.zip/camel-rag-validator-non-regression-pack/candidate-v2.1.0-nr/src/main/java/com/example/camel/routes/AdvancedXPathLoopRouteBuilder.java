package com.example.camel.routes;

import com.example.camel.strategy.StringAggregationStrategy;
import org.apache.camel.Exchange;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.language.xpath.XPathBuilder;
import org.apache.camel.support.builder.Namespaces;
import org.springframework.stereotype.Component;

/**
 * Examples avancés combinant XPath et les EIP Loop / Split / Choice.
 *
 * Le message attendu est un XML de type "order" utilisant les namespaces
 * urn:example:orders, urn:example:customer et urn:example:product.
 */
@Component
public class AdvancedXPathLoopRouteBuilder extends RouteBuilder {

    private static final Namespaces NS = new Namespaces("o", "urn:example:orders")
        .add("c", "urn:example:customer")
        .add("p", "urn:example:product");

    @Override
    public void configure() {
        /*
         * 1) XPath complexe : namespaces, count(), sum(), not(), prédicats imbriqués,
         *    extraction typée et Content-Based Router.
         */
        from("direct:xpathAdvanced")
            .routeId("xpath-advanced-classification")
            .streamCache(true)
            .setHeader("customerId", xpathString("string(/o:order/c:customer/@id)"))
            .setHeader("currency", xpathString("string(/o:order/@currency)"))
            .setHeader("lineCount", xpathNumber("count(/o:order/o:lines/o:line)"))
            .setHeader("activeAmount", xpathNumber("sum(/o:order/o:lines/o:line[@active='true']/@lineTotal)"))
            .choice()
                .when(xpathNs(
                    "/o:order[" +
                    "@priority='HIGH' " +
                    "and c:customer/@segment='VIP' " +
                    "and count(o:lines/o:line[@active='true']) >= 2 " +
                    "and sum(o:lines/o:line[@active='true']/@lineTotal) >= 1250 " +
                    "and not(o:flags/o:flag[@code='BLOCKED' or @code='FRAUD'])" +
                    "]"))
                    .setHeader("classification", constant("VIP_HIGH_VALUE"))
                .when(xpathNs(
                    "/o:order[o:lines/o:line[@hazardous='true' or @temperatureControlled='true']]"))
                    .setHeader("classification", constant("SPECIAL_HANDLING"))
                .otherwise()
                    .setHeader("classification", constant("STANDARD"))
            .end();

        /*
         * 2) Variables Camel dans XPath.
         * Les variables XPath $threshold et $region sont résolues depuis les
         * headers/propriétés/variables Camel selon les règles du langage XPath.
         */
        from("direct:xpathVariables")
            .routeId("xpath-variables")
            .streamCache(true)
            .choice()
                .when(xpathNs(
                    "sum(/o:order/o:lines/o:line[@active='true']/@lineTotal) >= number($threshold) " +
                    "and $region = 'EU' " +
                    "and not(/o:order/o:flags/o:flag[@code='BLOCKED'])"))
                    .setHeader("eligible", constant(true))
                .otherwise()
                    .setHeader("eligible", constant(false))
            .end();

        /*
         * 3) XPath 2.0 via Saxon : distinct-values + string-join.
         */
        from("direct:xpathSaxon")
            .routeId("xpath-saxon-functions")
            .streamCache(true)
            .setBody(xpathSaxonString(
                "string-join(sort(distinct-values(/o:order/o:lines/o:line/p:product/@category)), '|')"));

        /*
         * 4) Parcourir réellement des nœuds XML : Split(xpath(...)).
         * Ce n'est pas un Loop : chaque line devient le body d'un sous-Exchange.
         */
        from("direct:xpathSplitLines")
            .routeId("xpath-split-lines")
            .streamCache(true)
            .split(xpathNs("/o:order/o:lines/o:line[@active='true']"), new StringAggregationStrategy())
                .streaming()
                .setHeader("sku", xpathString("string(/*[local-name()='line']/*[local-name()='product']/@sku)"))
                .choice()
                    .when(xpath("/*[local-name()='line'][@hazardous='true' or number(@lineTotal) >= 450]"))
                        .setHeader("lineClass", constant("REVIEW"))
                    .otherwise()
                        .setHeader("lineClass", constant("STANDARD"))
                .end()
                .setBody(simple("${header.sku}:${header.lineClass}"))
            .end();

        /*
         * 5) Nombre de répétitions piloté directement par XPath.
         * CamelLoopIndex est disponible pendant chaque itération.
         */
        from("direct:loopXPathCount")
            .routeId("loop-xpath-count")
            .streamCache(true)
            .setHeader("loopTrace", constant(""))
            .loop(xpathNs("number(/o:order/@repetitions)"))
                .process(this::appendLoopIndex)
            .end()
            .setBody(header("loopTrace"));

        /*
         * 6) Boucle conditionnelle avancée : do/while piloté par XPath + Choice.
         *
         * - maxAttempts vient du XML ;
         * - $attempt vient d'un header Camel ;
         * - $continueProcessing vient d'une Exchange Property ;
         * - une règle XML BLOCKED peut interrompre les itérations ;
         * - succeedAt simule une condition métier atteinte dynamiquement.
         */
        from("direct:loopDoWhileAdvanced")
            .routeId("loop-do-while-advanced")
            .streamCache(true)
            .setHeader("attempt", constant(0))
            .setHeader("loopTrace", constant(""))
            .setProperty("continueProcessing", constant(true))
            .loopDoWhile(xpathNs(
                "$continueProcessing = true() " +
                "and number($attempt) < number(/o:order/@maxAttempts)"))
                .process(this::prepareConditionalIteration)
                .choice()
                    .when(xpathNs("/o:order/o:flags/o:flag[@code='BLOCKED']"))
                        .setHeader("loopOutcome", constant("BLOCKED"))
                        .setProperty("continueProcessing", constant(false))
                    .when(header("attemptReachedTarget").isEqualTo(true))
                        .setHeader("loopOutcome", constant("SUCCESS"))
                        .setProperty("continueProcessing", constant(false))
                    .otherwise()
                        .setHeader("loopOutcome", constant("RETRY"))
                .end()
            .end()
            .choice()
                .when(exchangeProperty("continueProcessing").isEqualTo(true))
                    .setHeader("loopOutcome", constant("MAX_ATTEMPTS"))
                    .setProperty("continueProcessing", constant(false))
            .end()
            .setBody(header("loopTrace"));

        // 7) Nouveau scénario V2 : scoring fraude combinant flags, pays et valeur.
        from("direct:xpathFraudScreening")
            .routeId("xpath-fraud-screening-v2")
            .streamCache(true)
            .choice()
                .when(xpathNs("/o:order[o:flags/o:flag[@code='FRAUD'] or (c:customer/c:country='XX' and sum(o:lines/o:line/@lineTotal) > 500)]"))
                    .setHeader("fraudDecision", constant("BLOCK"))
                .when(xpathNs("/o:order[sum(o:lines/o:line/@lineTotal) >= 2000]"))
                    .setHeader("fraudDecision", constant("REVIEW"))
                .otherwise()
                    .setHeader("fraudDecision", constant("ALLOW"))
            .end();
    }

    private void appendLoopIndex(Exchange exchange) {
        Integer index = exchange.getProperty("CamelLoopIndex", Integer.class);
        String trace = exchange.getMessage().getHeader("loopTrace", String.class);
        if (trace == null) {
            trace = "";
        }
        exchange.getMessage().setHeader("loopTrace", trace + index + ",");
    }

    private void prepareConditionalIteration(Exchange exchange) {
        Integer current = exchange.getMessage().getHeader("attempt", Integer.class);
        int attempt = (current == null ? 0 : current) + 1;
        exchange.getMessage().setHeader("attempt", attempt);

        Integer succeedAt = exchange.getMessage().getHeader("succeedAt", Integer.class);
        boolean reached = succeedAt != null && attempt >= succeedAt;
        exchange.getMessage().setHeader("attemptReachedTarget", reached);

        String trace = exchange.getMessage().getHeader("loopTrace", String.class);
        if (trace == null) {
            trace = "";
        }
        exchange.getMessage().setHeader("loopTrace", trace + "attempt-" + attempt + ";");
    }

    private XPathBuilder xpathNs(String expression) {
        return XPathBuilder.xpath(expression).namespaces(NS);
    }

    private XPathBuilder xpathString(String expression) {
        return XPathBuilder.xpath(expression, String.class).namespaces(NS);
    }

    private XPathBuilder xpathNumber(String expression) {
        return XPathBuilder.xpath(expression, Double.class).namespaces(NS);
    }

    private XPathBuilder xpathSaxonString(String expression) {
        return XPathBuilder.xpath(expression, String.class)
            .namespaces(NS)
            .saxon();
    }
}

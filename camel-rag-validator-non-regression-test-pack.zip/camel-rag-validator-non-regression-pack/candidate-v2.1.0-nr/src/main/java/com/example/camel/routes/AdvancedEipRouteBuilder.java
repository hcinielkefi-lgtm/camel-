package com.example.camel.routes;

import static org.apache.camel.builder.Builder.method;

import com.example.camel.service.DynamicRouterBean;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.ClaimCheckOperation;
import org.springframework.stereotype.Component;

@Component
public class AdvancedEipRouteBuilder extends RouteBuilder {
    @Override
    public void configure() {
        // Dynamic Router: la destination suivante est recalculée après chaque étape.
        from("direct:dynamicRouter")
            .routeId("dynamic-router")
            .dynamicRouter(method(DynamicRouterBean.class, "next"));

        // ToD: endpoint entièrement dynamique via Simple.
        from("direct:toD")
            .routeId("dynamic-to")
            .setHeader("dynamicDestination", constant("direct:stepB"))
            .toD("${header.dynamicDestination}");

        // Claim Check: met le message de côté, masque le corps, puis le restaure.
        from("direct:claimCheck")
            .routeId("claim-check")
            .claimCheck(ClaimCheckOperation.Set, "original")
            .setBody(constant("MASKED"))
            .claimCheck(ClaimCheckOperation.GetAndRemove, "original");

        // Sort: trie les tokens produits par l'expression.
        from("direct:sort")
            .routeId("sort")
            .sort(body().tokenize(","));

        // Resequencer batch: ordonne les messages selon l'en-tête seq.
        from("direct:resequence")
            .routeId("resequence")
            .resequence(header("seq")).batch().size(4).timeout(1500L)
            .to("seda:resequenced");

        from("seda:resequenced")
            .routeId("resequenced-output")
            .log("Resequenced seq=${header.seq}, body=${body}");

        // Validate et conversion de type.
        from("direct:validate")
            .routeId("validate-and-convert")
            .validate(header("required").isNotNull())
            .convertBodyTo(String.class)
            .setBody(simple("valid-v2:${body}"));

        // Route-scoped OnCompletion.
        from("direct:onCompletion")
            .routeId("on-completion")
            .onCompletion().onCompleteOnly()
                .setBody(simple("audit:${body}"))
                .to("seda:completionAudit")
            .end()
            .setBody(simple("completed-v2:${body}"));

        from("seda:completionAudit")
            .routeId("completion-audit")
            .log("Completion audit: ${body}");
    }
}

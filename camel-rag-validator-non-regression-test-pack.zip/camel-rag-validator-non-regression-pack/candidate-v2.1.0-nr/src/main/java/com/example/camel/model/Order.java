package com.example.camel.model;

import java.math.BigDecimal;

/** V2: ajout du canal d'origine pour simuler une évolution de contrat. */
public record Order(String id, BigDecimal amount, String productId, Integer quantity, String status, String channel) {
    public Order withStatus(String newStatus) {
        return new Order(id, amount, productId, quantity, newStatus, channel);
    }

    public Order withChannel(String newChannel) {
        return new Order(id, amount, productId, quantity, status, newChannel);
    }
}

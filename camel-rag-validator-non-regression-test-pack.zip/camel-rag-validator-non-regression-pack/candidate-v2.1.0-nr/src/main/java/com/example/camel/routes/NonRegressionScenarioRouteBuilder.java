package com.example.camel.routes;

import java.time.Instant;
import java.util.Map;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

/** Routes ajoutées uniquement dans le dataset V2 pour tester la détection d'ajouts. */
@Component
public class NonRegressionScenarioRouteBuilder extends RouteBuilder {
    @Override
    public void configure() {
        from("direct:nonRegressionFingerprint")
            .routeId("non-regression-fingerprint-v2")
            .setHeader("nrVersion", constant("2.1.0"))
            .process(e -> e.getMessage().setBody(Map.of(
                "dataset", "camel-rag-validator",
                "version", "2.1.0",
                "receivedBody", String.valueOf(e.getMessage().getBody()),
                "timestamp", Instant.now().toString()
            )));

        from("direct:nonRegressionBranch")
            .routeId("non-regression-branch-v2")
            .choice()
                .when(header("mode").isEqualTo("strict"))
                    .setBody(simple("STRICT-V2:${body}"))
                .when(header("mode").isEqualTo("compat"))
                    .setBody(simple("COMPAT-V2:${body}"))
                .otherwise()
                    .setBody(simple("DEFAULT-V2:${body}"))
            .end();
    }
}

package com.example.camel.routes;

import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

@Component
public class DatabaseRouteBuilder extends RouteBuilder {
    @Override
    public void configure() {
        from("direct:dbInsert")
            .routeId("db-insert-v2")
            .to("sql:INSERT INTO orders(id, amount, product_id, quantity, status, channel) "
                + "VALUES (:#id, :#amount, :#productId, :#quantity, :#status, :#channel)"
                + "?dataSource=#dataSource")
            .to("sql:INSERT INTO integration_audit(event_type, entity_id) VALUES ('ORDER_CREATED', :#id)?dataSource=#dataSource")
            .setBody(constant("inserted-v2"));

        from("direct:dbSelect")
            .routeId("db-select-v2")
            .to("sql:SELECT id, amount, product_id, quantity, status, channel, updated_at FROM orders WHERE id = :#id"
                + "?dataSource=#dataSource&outputType=SelectOne");

        from("direct:dbSelectAll")
            .routeId("db-select-all-v2")
            .to("sql:SELECT id, amount, product_id, quantity, status, channel, updated_at FROM orders ORDER BY updated_at DESC, id"
                + "?dataSource=#dataSource");

        from("direct:transact")
            .routeId("db-transaction-v2")
            .transacted()
            .to("sql:INSERT INTO orders(id, amount, product_id, quantity, status, channel) "
                + "VALUES (:#id, :#amount, :#productId, :#quantity, 'CREATED', :#channel)"
                + "?dataSource=#dataSource")
            .to("sql:UPDATE inventory SET qty = qty - :#quantity WHERE product_id = :#productId"
                + "?dataSource=#dataSource")
            .to("sql:INSERT INTO integration_audit(event_type, entity_id) VALUES ('ORDER_TX_COMMITTED', :#id)?dataSource=#dataSource")
            .choice()
                .when(header("forceRollback").isEqualTo(true))
                    .throwException(new IllegalStateException("forced rollback v2"))
            .end()
            .setBody(constant("committed-v2"));
    }
}

package com.example.camel;

import static org.assertj.core.api.Assertions.assertThat;

import org.apache.camel.ProducerTemplate;
import org.apache.camel.test.spring.junit5.CamelSpringBootTest;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@CamelSpringBootTest
@SpringBootTest(properties = {
    "demo.ibm-mq.enabled=false",
    "demo.kafka.enabled=false",
    "demo.oracle.enabled=false",
    "demo.enrichment.api.enabled=false"
})
class NonRegressionScenarioRouteTest {
    @Autowired ProducerTemplate producerTemplate;

    @Test
    void strictBranchUsesV2Contract() {
        Object result = producerTemplate.requestBodyAndHeader(
            "direct:nonRegressionBranch", "payload", "mode", "strict");
        assertThat(result).isEqualTo("STRICT-V2:payload");
    }
}

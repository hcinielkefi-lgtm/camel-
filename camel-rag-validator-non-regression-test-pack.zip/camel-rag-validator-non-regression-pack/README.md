# Camel RAG Validator — Non Regression Test Pack

Ce pack contient deux arbres complets destinés à un test de comparaison automatisé :

- `baseline-v2.0.0/` : version de référence ;
- `candidate-v2.1.0-nr/` : version volontairement modifiée ;
- `expected/` : oracle de comparaison (manifest JSON, matrice CSV, patch brut).

Le `non-regression-manifest.json` est la référence machine-friendly pour les nombres de fichiers modifiés/ajoutés/supprimés/renommés et les hashes attendus.
